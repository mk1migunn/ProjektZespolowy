﻿namespace Projekt_zespolowy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRzucKostka = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblNrPola20 = new System.Windows.Forms.Label();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.lblNrPola36 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel100 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel101 = new System.Windows.Forms.TableLayoutPanel();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.pictureBox151 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel102 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox152 = new System.Windows.Forms.PictureBox();
            this.pictureBox153 = new System.Windows.Forms.PictureBox();
            this.pictureBox154 = new System.Windows.Forms.PictureBox();
            this.pictureBox155 = new System.Windows.Forms.PictureBox();
            this.lblNrPola38 = new System.Windows.Forms.Label();
            this.tableLayoutPanel97 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel98 = new System.Windows.Forms.TableLayoutPanel();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.pictureBox146 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel99 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox147 = new System.Windows.Forms.PictureBox();
            this.pictureBox148 = new System.Windows.Forms.PictureBox();
            this.pictureBox149 = new System.Windows.Forms.PictureBox();
            this.pictureBox150 = new System.Windows.Forms.PictureBox();
            this.lblNrPola40 = new System.Windows.Forms.Label();
            this.tableLayoutPanel94 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel95 = new System.Windows.Forms.TableLayoutPanel();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.pictureBox141 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel96 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox142 = new System.Windows.Forms.PictureBox();
            this.pictureBox143 = new System.Windows.Forms.PictureBox();
            this.pictureBox144 = new System.Windows.Forms.PictureBox();
            this.pictureBox145 = new System.Windows.Forms.PictureBox();
            this.lblNrPola35 = new System.Windows.Forms.Label();
            this.tableLayoutPanel91 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel92 = new System.Windows.Forms.TableLayoutPanel();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.pictureBox136 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel93 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox137 = new System.Windows.Forms.PictureBox();
            this.pictureBox138 = new System.Windows.Forms.PictureBox();
            this.pictureBox139 = new System.Windows.Forms.PictureBox();
            this.pictureBox140 = new System.Windows.Forms.PictureBox();
            this.lblNrPola33 = new System.Windows.Forms.Label();
            this.tableLayoutPanel88 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel89 = new System.Windows.Forms.TableLayoutPanel();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.pictureBox131 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel90 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox132 = new System.Windows.Forms.PictureBox();
            this.pictureBox133 = new System.Windows.Forms.PictureBox();
            this.pictureBox134 = new System.Windows.Forms.PictureBox();
            this.pictureBox135 = new System.Windows.Forms.PictureBox();
            this.lblNrPola32 = new System.Windows.Forms.Label();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.lblNrPola16 = new System.Windows.Forms.Label();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel49 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel50 = new System.Windows.Forms.TableLayoutPanel();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.lblNrPola12 = new System.Windows.Forms.Label();
            this.tableLayoutPanel51 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel46 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel47 = new System.Windows.Forms.TableLayoutPanel();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblNrPola14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel48 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel43 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel44 = new System.Windows.Forms.TableLayoutPanel();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblNrPola15 = new System.Windows.Forms.Label();
            this.tableLayoutPanel45 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel40 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel41 = new System.Windows.Forms.TableLayoutPanel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblNrPola17 = new System.Windows.Forms.Label();
            this.tableLayoutPanel42 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblNrPola19 = new System.Windows.Forms.Label();
            this.tableLayoutPanel39 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.lblNrPola06 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel82 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola09 = new System.Windows.Forms.Label();
            this.tableLayoutPanel83 = new System.Windows.Forms.TableLayoutPanel();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.pictureBox121 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel84 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox122 = new System.Windows.Forms.PictureBox();
            this.pictureBox123 = new System.Windows.Forms.PictureBox();
            this.pictureBox124 = new System.Windows.Forms.PictureBox();
            this.pictureBox125 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel79 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel80 = new System.Windows.Forms.TableLayoutPanel();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.pictureBox116 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel81 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox117 = new System.Windows.Forms.PictureBox();
            this.pictureBox118 = new System.Windows.Forms.PictureBox();
            this.pictureBox119 = new System.Windows.Forms.PictureBox();
            this.pictureBox120 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel76 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola04 = new System.Windows.Forms.Label();
            this.tableLayoutPanel77 = new System.Windows.Forms.TableLayoutPanel();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.pictureBox111 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel78 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox112 = new System.Windows.Forms.PictureBox();
            this.pictureBox113 = new System.Windows.Forms.PictureBox();
            this.pictureBox114 = new System.Windows.Forms.PictureBox();
            this.pictureBox115 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola02 = new System.Windows.Forms.Label();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel85 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola07 = new System.Windows.Forms.Label();
            this.tableLayoutPanel86 = new System.Windows.Forms.TableLayoutPanel();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.pictureBox126 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel87 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox127 = new System.Windows.Forms.PictureBox();
            this.pictureBox128 = new System.Windows.Forms.PictureBox();
            this.pictureBox129 = new System.Windows.Forms.PictureBox();
            this.pictureBox130 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.lblNrPola26 = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tableLayoutPanel73 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola30 = new System.Windows.Forms.Label();
            this.tableLayoutPanel74 = new System.Windows.Forms.TableLayoutPanel();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.tableLayoutPanel75 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox106 = new System.Windows.Forms.PictureBox();
            this.pictureBox107 = new System.Windows.Forms.PictureBox();
            this.pictureBox108 = new System.Windows.Forms.PictureBox();
            this.pictureBox109 = new System.Windows.Forms.PictureBox();
            this.pictureBox110 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel70 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola28 = new System.Windows.Forms.Label();
            this.tableLayoutPanel71 = new System.Windows.Forms.TableLayoutPanel();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.tableLayoutPanel72 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox101 = new System.Windows.Forms.PictureBox();
            this.pictureBox102 = new System.Windows.Forms.PictureBox();
            this.pictureBox103 = new System.Windows.Forms.PictureBox();
            this.pictureBox104 = new System.Windows.Forms.PictureBox();
            this.pictureBox105 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel67 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola27 = new System.Windows.Forms.Label();
            this.tableLayoutPanel68 = new System.Windows.Forms.TableLayoutPanel();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.tableLayoutPanel69 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox96 = new System.Windows.Forms.PictureBox();
            this.pictureBox97 = new System.Windows.Forms.PictureBox();
            this.pictureBox98 = new System.Windows.Forms.PictureBox();
            this.pictureBox99 = new System.Windows.Forms.PictureBox();
            this.pictureBox100 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel64 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola25 = new System.Windows.Forms.Label();
            this.tableLayoutPanel65 = new System.Windows.Forms.TableLayoutPanel();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.tableLayoutPanel66 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox91 = new System.Windows.Forms.PictureBox();
            this.pictureBox92 = new System.Windows.Forms.PictureBox();
            this.pictureBox93 = new System.Windows.Forms.PictureBox();
            this.pictureBox94 = new System.Windows.Forms.PictureBox();
            this.pictureBox95 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel61 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola24 = new System.Windows.Forms.Label();
            this.tableLayoutPanel62 = new System.Windows.Forms.TableLayoutPanel();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.tableLayoutPanel63 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox86 = new System.Windows.Forms.PictureBox();
            this.pictureBox87 = new System.Windows.Forms.PictureBox();
            this.pictureBox88 = new System.Windows.Forms.PictureBox();
            this.pictureBox89 = new System.Windows.Forms.PictureBox();
            this.pictureBox90 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel58 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola22 = new System.Windows.Forms.Label();
            this.tableLayoutPanel59 = new System.Windows.Forms.TableLayoutPanel();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.tableLayoutPanel60 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox84 = new System.Windows.Forms.PictureBox();
            this.pictureBox85 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label35 = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.label98 = new System.Windows.Forms.Label();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.label106 = new System.Windows.Forms.Label();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola37 = new System.Windows.Forms.Label();
            this.lblNrPola34 = new System.Windows.Forms.Label();
            this.tableLayoutPanel52 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel53 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel54 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNrPola08 = new System.Windows.Forms.Label();
            this.lblNrPola23 = new System.Windows.Forms.Label();
            this.lblNrPola03 = new System.Windows.Forms.Label();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            this.tableLayoutPanel32.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel100.SuspendLayout();
            this.tableLayoutPanel101.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).BeginInit();
            this.tableLayoutPanel102.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).BeginInit();
            this.tableLayoutPanel97.SuspendLayout();
            this.tableLayoutPanel98.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).BeginInit();
            this.tableLayoutPanel99.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).BeginInit();
            this.tableLayoutPanel94.SuspendLayout();
            this.tableLayoutPanel95.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).BeginInit();
            this.tableLayoutPanel96.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).BeginInit();
            this.tableLayoutPanel91.SuspendLayout();
            this.tableLayoutPanel92.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).BeginInit();
            this.tableLayoutPanel93.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).BeginInit();
            this.tableLayoutPanel88.SuspendLayout();
            this.tableLayoutPanel89.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).BeginInit();
            this.tableLayoutPanel90.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).BeginInit();
            this.tableLayoutPanel35.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            this.tableLayoutPanel49.SuspendLayout();
            this.tableLayoutPanel50.SuspendLayout();
            this.tableLayoutPanel51.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            this.tableLayoutPanel46.SuspendLayout();
            this.tableLayoutPanel47.SuspendLayout();
            this.tableLayoutPanel48.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            this.tableLayoutPanel43.SuspendLayout();
            this.tableLayoutPanel44.SuspendLayout();
            this.tableLayoutPanel45.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            this.tableLayoutPanel40.SuspendLayout();
            this.tableLayoutPanel41.SuspendLayout();
            this.tableLayoutPanel42.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            this.tableLayoutPanel37.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.tableLayoutPanel39.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            this.tableLayoutPanel34.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            this.tableLayoutPanel26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            this.tableLayoutPanel82.SuspendLayout();
            this.tableLayoutPanel83.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).BeginInit();
            this.tableLayoutPanel84.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).BeginInit();
            this.tableLayoutPanel79.SuspendLayout();
            this.tableLayoutPanel80.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).BeginInit();
            this.tableLayoutPanel81.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).BeginInit();
            this.tableLayoutPanel76.SuspendLayout();
            this.tableLayoutPanel77.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).BeginInit();
            this.tableLayoutPanel78.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).BeginInit();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            this.tableLayoutPanel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            this.tableLayoutPanel85.SuspendLayout();
            this.tableLayoutPanel86.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).BeginInit();
            this.tableLayoutPanel87.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).BeginInit();
            this.tableLayoutPanel33.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.tableLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.tableLayoutPanel73.SuspendLayout();
            this.tableLayoutPanel74.SuspendLayout();
            this.tableLayoutPanel75.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).BeginInit();
            this.tableLayoutPanel70.SuspendLayout();
            this.tableLayoutPanel71.SuspendLayout();
            this.tableLayoutPanel72.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).BeginInit();
            this.tableLayoutPanel67.SuspendLayout();
            this.tableLayoutPanel68.SuspendLayout();
            this.tableLayoutPanel69.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).BeginInit();
            this.tableLayoutPanel64.SuspendLayout();
            this.tableLayoutPanel65.SuspendLayout();
            this.tableLayoutPanel66.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).BeginInit();
            this.tableLayoutPanel61.SuspendLayout();
            this.tableLayoutPanel62.SuspendLayout();
            this.tableLayoutPanel63.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).BeginInit();
            this.tableLayoutPanel58.SuspendLayout();
            this.tableLayoutPanel59.SuspendLayout();
            this.tableLayoutPanel60.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            this.tableLayoutPanel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            this.tableLayoutPanel24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel52.SuspendLayout();
            this.tableLayoutPanel53.SuspendLayout();
            this.tableLayoutPanel54.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRzucKostka
            // 
            this.btnRzucKostka.Location = new System.Drawing.Point(41, 68);
            this.btnRzucKostka.Name = "btnRzucKostka";
            this.btnRzucKostka.Size = new System.Drawing.Size(62, 59);
            this.btnRzucKostka.TabIndex = 0;
            this.btnRzucKostka.Text = "Rzuć!";
            this.btnRzucKostka.UseVisualStyleBackColor = true;
            this.btnRzucKostka.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(162, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 8;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 4;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel19, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.lblNrPola20, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel20, 3, 0);
            this.tableLayoutPanel18.Controls.Add(this.pictureBox20, 2, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel18.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel18.TabIndex = 13;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.label11, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel19.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel19.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Silver;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(1, 28);
            this.label11.Margin = new System.Windows.Forms.Padding(1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 26);
            this.label11.TabIndex = 10;
            this.label11.Text = "cena";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(1, 1);
            this.label12.Margin = new System.Windows.Forms.Padding(1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 25);
            this.label12.TabIndex = 10;
            this.label12.Text = "nazwa";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola20
            // 
            this.lblNrPola20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblNrPola20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola20.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola20.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola20.Name = "lblNrPola20";
            this.lblNrPola20.Size = new System.Drawing.Size(24, 55);
            this.lblNrPola20.TabIndex = 7;
            this.lblNrPola20.Text = "20";
            this.lblNrPola20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Controls.Add(this.pictureBox16, 1, 1);
            this.tableLayoutPanel20.Controls.Add(this.pictureBox17, 0, 1);
            this.tableLayoutPanel20.Controls.Add(this.pictureBox18, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.pictureBox19, 0, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(212, 1);
            this.tableLayoutPanel20.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 2;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(52, 55);
            this.tableLayoutPanel20.TabIndex = 10;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox16.Location = new System.Drawing.Point(27, 28);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(24, 26);
            this.pictureBox16.TabIndex = 12;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox17.Location = new System.Drawing.Point(1, 28);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(24, 26);
            this.pictureBox17.TabIndex = 11;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox18.Location = new System.Drawing.Point(27, 1);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(24, 25);
            this.pictureBox18.TabIndex = 10;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox19.Location = new System.Drawing.Point(1, 1);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(24, 25);
            this.pictureBox19.TabIndex = 9;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.White;
            this.pictureBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox20.Location = new System.Drawing.Point(106, 1);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(104, 55);
            this.pictureBox20.TabIndex = 9;
            this.pictureBox20.TabStop = false;
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel32.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel32.ColumnCount = 3;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel32.Controls.Add(this.tableLayoutPanel36, 2, 1);
            this.tableLayoutPanel32.Controls.Add(this.tableLayoutPanel35, 0, 1);
            this.tableLayoutPanel32.Controls.Add(this.tableLayoutPanel34, 1, 2);
            this.tableLayoutPanel32.Controls.Add(this.tableLayoutPanel33, 1, 0);
            this.tableLayoutPanel32.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.tableLayoutPanel32.Location = new System.Drawing.Point(322, 10);
            this.tableLayoutPanel32.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 3;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(1082, 900);
            this.tableLayoutPanel32.TabIndex = 16;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.ColumnCount = 1;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel30, 0, 5);
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel21, 0, 4);
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel29, 0, 2);
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel100, 0, 6);
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel97, 0, 8);
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel94, 0, 3);
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel91, 0, 1);
            this.tableLayoutPanel36.Controls.Add(this.tableLayoutPanel88, 0, 0);
            this.tableLayoutPanel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(812, 182);
            this.tableLayoutPanel36.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 9;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(268, 535);
            this.tableLayoutPanel36.TabIndex = 18;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 4;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel21.Controls.Add(this.pictureBox26, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.pictureBox27, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel22, 2, 0);
            this.tableLayoutPanel21.Controls.Add(this.lblNrPola36, 3, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(1, 237);
            this.tableLayoutPanel21.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(266, 57);
            this.tableLayoutPanel21.TabIndex = 24;
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.White;
            this.pictureBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox26.Location = new System.Drawing.Point(54, 1);
            this.pictureBox26.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(104, 55);
            this.pictureBox26.TabIndex = 9;
            this.pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox27.InitialImage = null;
            this.pictureBox27.Location = new System.Drawing.Point(1, 1);
            this.pictureBox27.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(51, 55);
            this.pictureBox27.TabIndex = 10;
            this.pictureBox27.TabStop = false;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel22.ColumnCount = 1;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Controls.Add(this.label95, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.label96, 0, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(160, 1);
            this.tableLayoutPanel22.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 2;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel22.TabIndex = 9;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.BackColor = System.Drawing.Color.Silver;
            this.label95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label95.Location = new System.Drawing.Point(1, 28);
            this.label95.Margin = new System.Windows.Forms.Padding(1);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(75, 26);
            this.label95.TabIndex = 10;
            this.label95.Text = "cena";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label96.Location = new System.Drawing.Point(1, 1);
            this.label96.Margin = new System.Windows.Forms.Padding(1);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(75, 25);
            this.label96.TabIndex = 10;
            this.label96.Text = "nazwa";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola36
            // 
            this.lblNrPola36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola36.Location = new System.Drawing.Point(239, 1);
            this.lblNrPola36.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola36.Name = "lblNrPola36";
            this.lblNrPola36.Size = new System.Drawing.Size(26, 55);
            this.lblNrPola36.TabIndex = 7;
            this.lblNrPola36.Text = "36";
            this.lblNrPola36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(239, 57);
            this.label7.TabIndex = 18;
            this.label7.Text = "?";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel100
            // 
            this.tableLayoutPanel100.ColumnCount = 4;
            this.tableLayoutPanel100.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel100.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel100.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel100.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel100.Controls.Add(this.tableLayoutPanel101, 2, 0);
            this.tableLayoutPanel100.Controls.Add(this.pictureBox151, 1, 0);
            this.tableLayoutPanel100.Controls.Add(this.tableLayoutPanel102, 0, 0);
            this.tableLayoutPanel100.Controls.Add(this.lblNrPola38, 3, 0);
            this.tableLayoutPanel100.Location = new System.Drawing.Point(1, 355);
            this.tableLayoutPanel100.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel100.Name = "tableLayoutPanel100";
            this.tableLayoutPanel100.RowCount = 1;
            this.tableLayoutPanel100.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel100.Size = new System.Drawing.Size(266, 57);
            this.tableLayoutPanel100.TabIndex = 19;
            // 
            // tableLayoutPanel101
            // 
            this.tableLayoutPanel101.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel101.ColumnCount = 1;
            this.tableLayoutPanel101.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel101.Controls.Add(this.label92, 0, 1);
            this.tableLayoutPanel101.Controls.Add(this.label93, 0, 0);
            this.tableLayoutPanel101.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel101.Location = new System.Drawing.Point(160, 1);
            this.tableLayoutPanel101.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel101.Name = "tableLayoutPanel101";
            this.tableLayoutPanel101.RowCount = 2;
            this.tableLayoutPanel101.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel101.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel101.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel101.TabIndex = 19;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.BackColor = System.Drawing.Color.Silver;
            this.label92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label92.Location = new System.Drawing.Point(1, 39);
            this.label92.Margin = new System.Windows.Forms.Padding(1);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(75, 15);
            this.label92.TabIndex = 10;
            this.label92.Text = "cena";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(1, 1);
            this.label93.Margin = new System.Windows.Forms.Padding(1);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(75, 36);
            this.label93.TabIndex = 10;
            this.label93.Text = "nazwa";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox151
            // 
            this.pictureBox151.BackColor = System.Drawing.Color.White;
            this.pictureBox151.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox151.Location = new System.Drawing.Point(54, 1);
            this.pictureBox151.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox151.Name = "pictureBox151";
            this.pictureBox151.Size = new System.Drawing.Size(104, 55);
            this.pictureBox151.TabIndex = 18;
            this.pictureBox151.TabStop = false;
            // 
            // tableLayoutPanel102
            // 
            this.tableLayoutPanel102.ColumnCount = 2;
            this.tableLayoutPanel102.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel102.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel102.Controls.Add(this.pictureBox152, 1, 1);
            this.tableLayoutPanel102.Controls.Add(this.pictureBox153, 0, 1);
            this.tableLayoutPanel102.Controls.Add(this.pictureBox154, 1, 0);
            this.tableLayoutPanel102.Controls.Add(this.pictureBox155, 0, 0);
            this.tableLayoutPanel102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel102.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel102.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel102.Name = "tableLayoutPanel102";
            this.tableLayoutPanel102.RowCount = 2;
            this.tableLayoutPanel102.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel102.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel102.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel102.Size = new System.Drawing.Size(51, 55);
            this.tableLayoutPanel102.TabIndex = 17;
            // 
            // pictureBox152
            // 
            this.pictureBox152.BackColor = System.Drawing.Color.Black;
            this.pictureBox152.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox152.Location = new System.Drawing.Point(26, 28);
            this.pictureBox152.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox152.Name = "pictureBox152";
            this.pictureBox152.Size = new System.Drawing.Size(24, 26);
            this.pictureBox152.TabIndex = 12;
            this.pictureBox152.TabStop = false;
            // 
            // pictureBox153
            // 
            this.pictureBox153.BackColor = System.Drawing.Color.Black;
            this.pictureBox153.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox153.Location = new System.Drawing.Point(1, 28);
            this.pictureBox153.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox153.Name = "pictureBox153";
            this.pictureBox153.Size = new System.Drawing.Size(23, 26);
            this.pictureBox153.TabIndex = 11;
            this.pictureBox153.TabStop = false;
            // 
            // pictureBox154
            // 
            this.pictureBox154.BackColor = System.Drawing.Color.Black;
            this.pictureBox154.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox154.Location = new System.Drawing.Point(26, 1);
            this.pictureBox154.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox154.Name = "pictureBox154";
            this.pictureBox154.Size = new System.Drawing.Size(24, 25);
            this.pictureBox154.TabIndex = 10;
            this.pictureBox154.TabStop = false;
            // 
            // pictureBox155
            // 
            this.pictureBox155.BackColor = System.Drawing.Color.Black;
            this.pictureBox155.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox155.Location = new System.Drawing.Point(1, 1);
            this.pictureBox155.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox155.Name = "pictureBox155";
            this.pictureBox155.Size = new System.Drawing.Size(23, 25);
            this.pictureBox155.TabIndex = 9;
            this.pictureBox155.TabStop = false;
            // 
            // lblNrPola38
            // 
            this.lblNrPola38.BackColor = System.Drawing.Color.Black;
            this.lblNrPola38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola38.ForeColor = System.Drawing.Color.White;
            this.lblNrPola38.Location = new System.Drawing.Point(239, 1);
            this.lblNrPola38.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola38.Name = "lblNrPola38";
            this.lblNrPola38.Size = new System.Drawing.Size(26, 55);
            this.lblNrPola38.TabIndex = 19;
            this.lblNrPola38.Text = "38";
            this.lblNrPola38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel97
            // 
            this.tableLayoutPanel97.ColumnCount = 4;
            this.tableLayoutPanel97.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel97.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel97.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel97.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel97.Controls.Add(this.tableLayoutPanel98, 2, 0);
            this.tableLayoutPanel97.Controls.Add(this.pictureBox146, 1, 0);
            this.tableLayoutPanel97.Controls.Add(this.tableLayoutPanel99, 0, 0);
            this.tableLayoutPanel97.Controls.Add(this.lblNrPola40, 3, 0);
            this.tableLayoutPanel97.Location = new System.Drawing.Point(1, 473);
            this.tableLayoutPanel97.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel97.Name = "tableLayoutPanel97";
            this.tableLayoutPanel97.RowCount = 1;
            this.tableLayoutPanel97.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel97.Size = new System.Drawing.Size(266, 61);
            this.tableLayoutPanel97.TabIndex = 19;
            // 
            // tableLayoutPanel98
            // 
            this.tableLayoutPanel98.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel98.ColumnCount = 1;
            this.tableLayoutPanel98.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel98.Controls.Add(this.label89, 0, 1);
            this.tableLayoutPanel98.Controls.Add(this.label90, 0, 0);
            this.tableLayoutPanel98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel98.Location = new System.Drawing.Point(160, 1);
            this.tableLayoutPanel98.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel98.Name = "tableLayoutPanel98";
            this.tableLayoutPanel98.RowCount = 2;
            this.tableLayoutPanel98.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel98.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel98.Size = new System.Drawing.Size(77, 59);
            this.tableLayoutPanel98.TabIndex = 19;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.Silver;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(1, 42);
            this.label89.Margin = new System.Windows.Forms.Padding(1);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(75, 16);
            this.label89.TabIndex = 10;
            this.label89.Text = "cena";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(1, 1);
            this.label90.Margin = new System.Windows.Forms.Padding(1);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(75, 39);
            this.label90.TabIndex = 10;
            this.label90.Text = "nazwa";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox146
            // 
            this.pictureBox146.BackColor = System.Drawing.Color.White;
            this.pictureBox146.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox146.Location = new System.Drawing.Point(54, 1);
            this.pictureBox146.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox146.Name = "pictureBox146";
            this.pictureBox146.Size = new System.Drawing.Size(104, 59);
            this.pictureBox146.TabIndex = 18;
            this.pictureBox146.TabStop = false;
            // 
            // tableLayoutPanel99
            // 
            this.tableLayoutPanel99.ColumnCount = 2;
            this.tableLayoutPanel99.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel99.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel99.Controls.Add(this.pictureBox147, 1, 1);
            this.tableLayoutPanel99.Controls.Add(this.pictureBox148, 0, 1);
            this.tableLayoutPanel99.Controls.Add(this.pictureBox149, 1, 0);
            this.tableLayoutPanel99.Controls.Add(this.pictureBox150, 0, 0);
            this.tableLayoutPanel99.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel99.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel99.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel99.Name = "tableLayoutPanel99";
            this.tableLayoutPanel99.RowCount = 2;
            this.tableLayoutPanel99.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel99.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel99.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel99.Size = new System.Drawing.Size(51, 59);
            this.tableLayoutPanel99.TabIndex = 17;
            // 
            // pictureBox147
            // 
            this.pictureBox147.BackColor = System.Drawing.Color.Black;
            this.pictureBox147.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox147.Location = new System.Drawing.Point(26, 30);
            this.pictureBox147.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox147.Name = "pictureBox147";
            this.pictureBox147.Size = new System.Drawing.Size(24, 28);
            this.pictureBox147.TabIndex = 12;
            this.pictureBox147.TabStop = false;
            // 
            // pictureBox148
            // 
            this.pictureBox148.BackColor = System.Drawing.Color.Black;
            this.pictureBox148.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox148.Location = new System.Drawing.Point(1, 30);
            this.pictureBox148.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox148.Name = "pictureBox148";
            this.pictureBox148.Size = new System.Drawing.Size(23, 28);
            this.pictureBox148.TabIndex = 11;
            this.pictureBox148.TabStop = false;
            // 
            // pictureBox149
            // 
            this.pictureBox149.BackColor = System.Drawing.Color.Black;
            this.pictureBox149.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox149.Location = new System.Drawing.Point(26, 1);
            this.pictureBox149.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox149.Name = "pictureBox149";
            this.pictureBox149.Size = new System.Drawing.Size(24, 27);
            this.pictureBox149.TabIndex = 10;
            this.pictureBox149.TabStop = false;
            // 
            // pictureBox150
            // 
            this.pictureBox150.BackColor = System.Drawing.Color.Black;
            this.pictureBox150.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox150.Location = new System.Drawing.Point(1, 1);
            this.pictureBox150.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox150.Name = "pictureBox150";
            this.pictureBox150.Size = new System.Drawing.Size(23, 27);
            this.pictureBox150.TabIndex = 9;
            this.pictureBox150.TabStop = false;
            // 
            // lblNrPola40
            // 
            this.lblNrPola40.BackColor = System.Drawing.Color.Black;
            this.lblNrPola40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola40.ForeColor = System.Drawing.Color.White;
            this.lblNrPola40.Location = new System.Drawing.Point(239, 1);
            this.lblNrPola40.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola40.Name = "lblNrPola40";
            this.lblNrPola40.Size = new System.Drawing.Size(26, 59);
            this.lblNrPola40.TabIndex = 19;
            this.lblNrPola40.Text = "40";
            this.lblNrPola40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel94
            // 
            this.tableLayoutPanel94.ColumnCount = 4;
            this.tableLayoutPanel94.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel94.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel94.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel94.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel94.Controls.Add(this.tableLayoutPanel95, 2, 0);
            this.tableLayoutPanel94.Controls.Add(this.pictureBox141, 1, 0);
            this.tableLayoutPanel94.Controls.Add(this.tableLayoutPanel96, 0, 0);
            this.tableLayoutPanel94.Controls.Add(this.lblNrPola35, 3, 0);
            this.tableLayoutPanel94.Location = new System.Drawing.Point(1, 178);
            this.tableLayoutPanel94.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel94.Name = "tableLayoutPanel94";
            this.tableLayoutPanel94.RowCount = 1;
            this.tableLayoutPanel94.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel94.Size = new System.Drawing.Size(266, 57);
            this.tableLayoutPanel94.TabIndex = 19;
            // 
            // tableLayoutPanel95
            // 
            this.tableLayoutPanel95.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel95.ColumnCount = 1;
            this.tableLayoutPanel95.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel95.Controls.Add(this.label86, 0, 1);
            this.tableLayoutPanel95.Controls.Add(this.label87, 0, 0);
            this.tableLayoutPanel95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel95.Location = new System.Drawing.Point(160, 1);
            this.tableLayoutPanel95.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel95.Name = "tableLayoutPanel95";
            this.tableLayoutPanel95.RowCount = 2;
            this.tableLayoutPanel95.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel95.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel95.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel95.TabIndex = 19;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.Silver;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(1, 39);
            this.label86.Margin = new System.Windows.Forms.Padding(1);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(75, 15);
            this.label86.TabIndex = 10;
            this.label86.Text = "cena";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(1, 1);
            this.label87.Margin = new System.Windows.Forms.Padding(1);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(75, 36);
            this.label87.TabIndex = 10;
            this.label87.Text = "nazwa";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox141
            // 
            this.pictureBox141.BackColor = System.Drawing.Color.White;
            this.pictureBox141.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox141.Location = new System.Drawing.Point(54, 1);
            this.pictureBox141.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox141.Name = "pictureBox141";
            this.pictureBox141.Size = new System.Drawing.Size(104, 55);
            this.pictureBox141.TabIndex = 18;
            this.pictureBox141.TabStop = false;
            // 
            // tableLayoutPanel96
            // 
            this.tableLayoutPanel96.ColumnCount = 2;
            this.tableLayoutPanel96.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel96.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel96.Controls.Add(this.pictureBox142, 1, 1);
            this.tableLayoutPanel96.Controls.Add(this.pictureBox143, 0, 1);
            this.tableLayoutPanel96.Controls.Add(this.pictureBox144, 1, 0);
            this.tableLayoutPanel96.Controls.Add(this.pictureBox145, 0, 0);
            this.tableLayoutPanel96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel96.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel96.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel96.Name = "tableLayoutPanel96";
            this.tableLayoutPanel96.RowCount = 2;
            this.tableLayoutPanel96.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel96.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel96.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel96.Size = new System.Drawing.Size(51, 55);
            this.tableLayoutPanel96.TabIndex = 17;
            // 
            // pictureBox142
            // 
            this.pictureBox142.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox142.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox142.Location = new System.Drawing.Point(26, 28);
            this.pictureBox142.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox142.Name = "pictureBox142";
            this.pictureBox142.Size = new System.Drawing.Size(24, 26);
            this.pictureBox142.TabIndex = 12;
            this.pictureBox142.TabStop = false;
            // 
            // pictureBox143
            // 
            this.pictureBox143.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox143.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox143.Location = new System.Drawing.Point(1, 28);
            this.pictureBox143.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox143.Name = "pictureBox143";
            this.pictureBox143.Size = new System.Drawing.Size(23, 26);
            this.pictureBox143.TabIndex = 11;
            this.pictureBox143.TabStop = false;
            // 
            // pictureBox144
            // 
            this.pictureBox144.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox144.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox144.Location = new System.Drawing.Point(26, 1);
            this.pictureBox144.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox144.Name = "pictureBox144";
            this.pictureBox144.Size = new System.Drawing.Size(24, 25);
            this.pictureBox144.TabIndex = 10;
            this.pictureBox144.TabStop = false;
            // 
            // pictureBox145
            // 
            this.pictureBox145.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox145.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox145.Location = new System.Drawing.Point(1, 1);
            this.pictureBox145.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox145.Name = "pictureBox145";
            this.pictureBox145.Size = new System.Drawing.Size(23, 25);
            this.pictureBox145.TabIndex = 9;
            this.pictureBox145.TabStop = false;
            // 
            // lblNrPola35
            // 
            this.lblNrPola35.BackColor = System.Drawing.Color.Maroon;
            this.lblNrPola35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola35.ForeColor = System.Drawing.Color.White;
            this.lblNrPola35.Location = new System.Drawing.Point(239, 1);
            this.lblNrPola35.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola35.Name = "lblNrPola35";
            this.lblNrPola35.Size = new System.Drawing.Size(26, 55);
            this.lblNrPola35.TabIndex = 19;
            this.lblNrPola35.Text = "35";
            this.lblNrPola35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel91
            // 
            this.tableLayoutPanel91.ColumnCount = 4;
            this.tableLayoutPanel91.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel91.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel91.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel91.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel91.Controls.Add(this.tableLayoutPanel92, 2, 0);
            this.tableLayoutPanel91.Controls.Add(this.pictureBox136, 1, 0);
            this.tableLayoutPanel91.Controls.Add(this.tableLayoutPanel93, 0, 0);
            this.tableLayoutPanel91.Controls.Add(this.lblNrPola33, 3, 0);
            this.tableLayoutPanel91.Location = new System.Drawing.Point(1, 60);
            this.tableLayoutPanel91.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel91.Name = "tableLayoutPanel91";
            this.tableLayoutPanel91.RowCount = 1;
            this.tableLayoutPanel91.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel91.Size = new System.Drawing.Size(266, 57);
            this.tableLayoutPanel91.TabIndex = 19;
            // 
            // tableLayoutPanel92
            // 
            this.tableLayoutPanel92.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel92.ColumnCount = 1;
            this.tableLayoutPanel92.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel92.Controls.Add(this.label83, 0, 1);
            this.tableLayoutPanel92.Controls.Add(this.label84, 0, 0);
            this.tableLayoutPanel92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel92.Location = new System.Drawing.Point(160, 1);
            this.tableLayoutPanel92.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel92.Name = "tableLayoutPanel92";
            this.tableLayoutPanel92.RowCount = 2;
            this.tableLayoutPanel92.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel92.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel92.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel92.TabIndex = 19;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.Color.Silver;
            this.label83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label83.Location = new System.Drawing.Point(1, 39);
            this.label83.Margin = new System.Windows.Forms.Padding(1);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(75, 15);
            this.label83.TabIndex = 10;
            this.label83.Text = "cena";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label84.Location = new System.Drawing.Point(1, 1);
            this.label84.Margin = new System.Windows.Forms.Padding(1);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(75, 36);
            this.label84.TabIndex = 10;
            this.label84.Text = "nazwa";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox136
            // 
            this.pictureBox136.BackColor = System.Drawing.Color.White;
            this.pictureBox136.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox136.Location = new System.Drawing.Point(54, 1);
            this.pictureBox136.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox136.Name = "pictureBox136";
            this.pictureBox136.Size = new System.Drawing.Size(104, 55);
            this.pictureBox136.TabIndex = 18;
            this.pictureBox136.TabStop = false;
            // 
            // tableLayoutPanel93
            // 
            this.tableLayoutPanel93.ColumnCount = 2;
            this.tableLayoutPanel93.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel93.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel93.Controls.Add(this.pictureBox137, 1, 1);
            this.tableLayoutPanel93.Controls.Add(this.pictureBox138, 0, 1);
            this.tableLayoutPanel93.Controls.Add(this.pictureBox139, 1, 0);
            this.tableLayoutPanel93.Controls.Add(this.pictureBox140, 0, 0);
            this.tableLayoutPanel93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel93.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel93.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel93.Name = "tableLayoutPanel93";
            this.tableLayoutPanel93.RowCount = 2;
            this.tableLayoutPanel93.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel93.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel93.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel93.Size = new System.Drawing.Size(51, 55);
            this.tableLayoutPanel93.TabIndex = 17;
            // 
            // pictureBox137
            // 
            this.pictureBox137.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox137.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox137.Location = new System.Drawing.Point(26, 28);
            this.pictureBox137.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox137.Name = "pictureBox137";
            this.pictureBox137.Size = new System.Drawing.Size(24, 26);
            this.pictureBox137.TabIndex = 12;
            this.pictureBox137.TabStop = false;
            // 
            // pictureBox138
            // 
            this.pictureBox138.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox138.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox138.Location = new System.Drawing.Point(1, 28);
            this.pictureBox138.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox138.Name = "pictureBox138";
            this.pictureBox138.Size = new System.Drawing.Size(23, 26);
            this.pictureBox138.TabIndex = 11;
            this.pictureBox138.TabStop = false;
            // 
            // pictureBox139
            // 
            this.pictureBox139.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox139.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox139.Location = new System.Drawing.Point(26, 1);
            this.pictureBox139.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox139.Name = "pictureBox139";
            this.pictureBox139.Size = new System.Drawing.Size(24, 25);
            this.pictureBox139.TabIndex = 10;
            this.pictureBox139.TabStop = false;
            // 
            // pictureBox140
            // 
            this.pictureBox140.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox140.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox140.Location = new System.Drawing.Point(1, 1);
            this.pictureBox140.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox140.Name = "pictureBox140";
            this.pictureBox140.Size = new System.Drawing.Size(23, 25);
            this.pictureBox140.TabIndex = 9;
            this.pictureBox140.TabStop = false;
            // 
            // lblNrPola33
            // 
            this.lblNrPola33.BackColor = System.Drawing.Color.Maroon;
            this.lblNrPola33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola33.ForeColor = System.Drawing.Color.White;
            this.lblNrPola33.Location = new System.Drawing.Point(239, 1);
            this.lblNrPola33.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola33.Name = "lblNrPola33";
            this.lblNrPola33.Size = new System.Drawing.Size(26, 55);
            this.lblNrPola33.TabIndex = 19;
            this.lblNrPola33.Text = "33";
            this.lblNrPola33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel88
            // 
            this.tableLayoutPanel88.ColumnCount = 4;
            this.tableLayoutPanel88.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel88.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel88.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel88.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel88.Controls.Add(this.tableLayoutPanel89, 2, 0);
            this.tableLayoutPanel88.Controls.Add(this.pictureBox131, 1, 0);
            this.tableLayoutPanel88.Controls.Add(this.tableLayoutPanel90, 0, 0);
            this.tableLayoutPanel88.Controls.Add(this.lblNrPola32, 3, 0);
            this.tableLayoutPanel88.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel88.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel88.Name = "tableLayoutPanel88";
            this.tableLayoutPanel88.RowCount = 1;
            this.tableLayoutPanel88.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel88.Size = new System.Drawing.Size(266, 57);
            this.tableLayoutPanel88.TabIndex = 19;
            // 
            // tableLayoutPanel89
            // 
            this.tableLayoutPanel89.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel89.ColumnCount = 1;
            this.tableLayoutPanel89.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel89.Controls.Add(this.label80, 0, 1);
            this.tableLayoutPanel89.Controls.Add(this.label81, 0, 0);
            this.tableLayoutPanel89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel89.Location = new System.Drawing.Point(160, 1);
            this.tableLayoutPanel89.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel89.Name = "tableLayoutPanel89";
            this.tableLayoutPanel89.RowCount = 2;
            this.tableLayoutPanel89.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel89.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel89.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel89.TabIndex = 19;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.BackColor = System.Drawing.Color.Silver;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Location = new System.Drawing.Point(1, 39);
            this.label80.Margin = new System.Windows.Forms.Padding(1);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(75, 15);
            this.label80.TabIndex = 10;
            this.label80.Text = "cena";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(1, 1);
            this.label81.Margin = new System.Windows.Forms.Padding(1);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(75, 36);
            this.label81.TabIndex = 10;
            this.label81.Text = "nazwa";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox131
            // 
            this.pictureBox131.BackColor = System.Drawing.Color.White;
            this.pictureBox131.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox131.Location = new System.Drawing.Point(54, 1);
            this.pictureBox131.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox131.Name = "pictureBox131";
            this.pictureBox131.Size = new System.Drawing.Size(104, 55);
            this.pictureBox131.TabIndex = 18;
            this.pictureBox131.TabStop = false;
            // 
            // tableLayoutPanel90
            // 
            this.tableLayoutPanel90.ColumnCount = 2;
            this.tableLayoutPanel90.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel90.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel90.Controls.Add(this.pictureBox132, 1, 1);
            this.tableLayoutPanel90.Controls.Add(this.pictureBox133, 0, 1);
            this.tableLayoutPanel90.Controls.Add(this.pictureBox134, 1, 0);
            this.tableLayoutPanel90.Controls.Add(this.pictureBox135, 0, 0);
            this.tableLayoutPanel90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel90.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel90.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel90.Name = "tableLayoutPanel90";
            this.tableLayoutPanel90.RowCount = 2;
            this.tableLayoutPanel90.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel90.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel90.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel90.Size = new System.Drawing.Size(51, 55);
            this.tableLayoutPanel90.TabIndex = 17;
            // 
            // pictureBox132
            // 
            this.pictureBox132.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox132.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox132.Location = new System.Drawing.Point(26, 28);
            this.pictureBox132.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox132.Name = "pictureBox132";
            this.pictureBox132.Size = new System.Drawing.Size(24, 26);
            this.pictureBox132.TabIndex = 12;
            this.pictureBox132.TabStop = false;
            // 
            // pictureBox133
            // 
            this.pictureBox133.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox133.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox133.Location = new System.Drawing.Point(1, 28);
            this.pictureBox133.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox133.Name = "pictureBox133";
            this.pictureBox133.Size = new System.Drawing.Size(23, 26);
            this.pictureBox133.TabIndex = 11;
            this.pictureBox133.TabStop = false;
            // 
            // pictureBox134
            // 
            this.pictureBox134.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox134.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox134.Location = new System.Drawing.Point(26, 1);
            this.pictureBox134.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox134.Name = "pictureBox134";
            this.pictureBox134.Size = new System.Drawing.Size(24, 25);
            this.pictureBox134.TabIndex = 10;
            this.pictureBox134.TabStop = false;
            // 
            // pictureBox135
            // 
            this.pictureBox135.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox135.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox135.Location = new System.Drawing.Point(1, 1);
            this.pictureBox135.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox135.Name = "pictureBox135";
            this.pictureBox135.Size = new System.Drawing.Size(23, 25);
            this.pictureBox135.TabIndex = 9;
            this.pictureBox135.TabStop = false;
            // 
            // lblNrPola32
            // 
            this.lblNrPola32.BackColor = System.Drawing.Color.Maroon;
            this.lblNrPola32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola32.ForeColor = System.Drawing.Color.White;
            this.lblNrPola32.Location = new System.Drawing.Point(239, 1);
            this.lblNrPola32.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola32.Name = "lblNrPola32";
            this.lblNrPola32.Size = new System.Drawing.Size(26, 55);
            this.lblNrPola32.TabIndex = 19;
            this.lblNrPola32.Text = "32";
            this.lblNrPola32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.ColumnCount = 1;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel28, 0, 2);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel14, 0, 4);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel49, 0, 8);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel46, 0, 6);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel43, 0, 5);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel40, 0, 3);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel37, 0, 1);
            this.tableLayoutPanel35.Controls.Add(this.tableLayoutPanel18, 0, 0);
            this.tableLayoutPanel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel35.Location = new System.Drawing.Point(2, 182);
            this.tableLayoutPanel35.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 9;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(267, 535);
            this.tableLayoutPanel35.TabIndex = 17;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 4;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel15, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.lblNrPola16, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox21, 2, 0);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox22, 3, 0);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(1, 237);
            this.tableLayoutPanel14.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel14.TabIndex = 23;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.label41, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.label42, 0, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel15.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel15.TabIndex = 9;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Silver;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(1, 28);
            this.label41.Margin = new System.Windows.Forms.Padding(1);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(75, 26);
            this.label41.TabIndex = 10;
            this.label41.Text = "cena";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(1, 1);
            this.label42.Margin = new System.Windows.Forms.Padding(1);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(75, 25);
            this.label42.TabIndex = 10;
            this.label42.Text = "nazwa";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola16
            // 
            this.lblNrPola16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola16.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola16.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola16.Name = "lblNrPola16";
            this.lblNrPola16.Size = new System.Drawing.Size(24, 55);
            this.lblNrPola16.TabIndex = 7;
            this.lblNrPola16.Text = "16";
            this.lblNrPola16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.White;
            this.pictureBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox21.Location = new System.Drawing.Point(106, 1);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(104, 55);
            this.pictureBox21.TabIndex = 9;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox22.InitialImage = null;
            this.pictureBox22.Location = new System.Drawing.Point(212, 1);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(52, 55);
            this.pictureBox22.TabIndex = 10;
            this.pictureBox22.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(26, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(239, 57);
            this.label3.TabIndex = 19;
            this.label3.Text = "?";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel49
            // 
            this.tableLayoutPanel49.ColumnCount = 4;
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel49.Controls.Add(this.tableLayoutPanel50, 1, 0);
            this.tableLayoutPanel49.Controls.Add(this.lblNrPola12, 0, 0);
            this.tableLayoutPanel49.Controls.Add(this.tableLayoutPanel51, 3, 0);
            this.tableLayoutPanel49.Controls.Add(this.pictureBox55, 2, 0);
            this.tableLayoutPanel49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel49.Location = new System.Drawing.Point(1, 473);
            this.tableLayoutPanel49.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel49.Name = "tableLayoutPanel49";
            this.tableLayoutPanel49.RowCount = 1;
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel49.Size = new System.Drawing.Size(265, 61);
            this.tableLayoutPanel49.TabIndex = 17;
            // 
            // tableLayoutPanel50
            // 
            this.tableLayoutPanel50.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel50.ColumnCount = 1;
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel50.Controls.Add(this.label32, 0, 1);
            this.tableLayoutPanel50.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel50.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel50.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel50.Name = "tableLayoutPanel50";
            this.tableLayoutPanel50.RowCount = 2;
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel50.Size = new System.Drawing.Size(77, 59);
            this.tableLayoutPanel50.TabIndex = 9;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Silver;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(1, 30);
            this.label32.Margin = new System.Windows.Forms.Padding(1);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(75, 28);
            this.label32.TabIndex = 10;
            this.label32.Text = "cena";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(1, 1);
            this.label33.Margin = new System.Windows.Forms.Padding(1);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(75, 27);
            this.label33.TabIndex = 10;
            this.label33.Text = "nazwa";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola12
            // 
            this.lblNrPola12.BackColor = System.Drawing.Color.Blue;
            this.lblNrPola12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola12.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola12.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola12.Name = "lblNrPola12";
            this.lblNrPola12.Size = new System.Drawing.Size(24, 59);
            this.lblNrPola12.TabIndex = 7;
            this.lblNrPola12.Text = "12";
            this.lblNrPola12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel51
            // 
            this.tableLayoutPanel51.ColumnCount = 2;
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel51.Controls.Add(this.pictureBox51, 1, 1);
            this.tableLayoutPanel51.Controls.Add(this.pictureBox52, 0, 1);
            this.tableLayoutPanel51.Controls.Add(this.pictureBox53, 1, 0);
            this.tableLayoutPanel51.Controls.Add(this.pictureBox54, 0, 0);
            this.tableLayoutPanel51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel51.Location = new System.Drawing.Point(212, 1);
            this.tableLayoutPanel51.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel51.Name = "tableLayoutPanel51";
            this.tableLayoutPanel51.RowCount = 2;
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel51.Size = new System.Drawing.Size(52, 59);
            this.tableLayoutPanel51.TabIndex = 10;
            // 
            // pictureBox51
            // 
            this.pictureBox51.BackColor = System.Drawing.Color.Blue;
            this.pictureBox51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox51.Location = new System.Drawing.Point(27, 30);
            this.pictureBox51.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(24, 28);
            this.pictureBox51.TabIndex = 12;
            this.pictureBox51.TabStop = false;
            // 
            // pictureBox52
            // 
            this.pictureBox52.BackColor = System.Drawing.Color.Blue;
            this.pictureBox52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox52.Location = new System.Drawing.Point(1, 30);
            this.pictureBox52.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(24, 28);
            this.pictureBox52.TabIndex = 11;
            this.pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            this.pictureBox53.BackColor = System.Drawing.Color.Blue;
            this.pictureBox53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox53.Location = new System.Drawing.Point(27, 1);
            this.pictureBox53.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(24, 27);
            this.pictureBox53.TabIndex = 10;
            this.pictureBox53.TabStop = false;
            // 
            // pictureBox54
            // 
            this.pictureBox54.BackColor = System.Drawing.Color.Blue;
            this.pictureBox54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox54.Location = new System.Drawing.Point(1, 1);
            this.pictureBox54.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(24, 27);
            this.pictureBox54.TabIndex = 9;
            this.pictureBox54.TabStop = false;
            // 
            // pictureBox55
            // 
            this.pictureBox55.BackColor = System.Drawing.Color.White;
            this.pictureBox55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox55.Location = new System.Drawing.Point(106, 1);
            this.pictureBox55.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(104, 59);
            this.pictureBox55.TabIndex = 9;
            this.pictureBox55.TabStop = false;
            // 
            // tableLayoutPanel46
            // 
            this.tableLayoutPanel46.ColumnCount = 4;
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel46.Controls.Add(this.tableLayoutPanel47, 1, 0);
            this.tableLayoutPanel46.Controls.Add(this.lblNrPola14, 0, 0);
            this.tableLayoutPanel46.Controls.Add(this.tableLayoutPanel48, 3, 0);
            this.tableLayoutPanel46.Controls.Add(this.pictureBox50, 2, 0);
            this.tableLayoutPanel46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel46.Location = new System.Drawing.Point(1, 355);
            this.tableLayoutPanel46.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel46.Name = "tableLayoutPanel46";
            this.tableLayoutPanel46.RowCount = 1;
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel46.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel46.TabIndex = 17;
            // 
            // tableLayoutPanel47
            // 
            this.tableLayoutPanel47.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel47.ColumnCount = 1;
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel47.Controls.Add(this.label29, 0, 1);
            this.tableLayoutPanel47.Controls.Add(this.label30, 0, 0);
            this.tableLayoutPanel47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel47.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel47.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel47.Name = "tableLayoutPanel47";
            this.tableLayoutPanel47.RowCount = 2;
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel47.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel47.TabIndex = 9;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Silver;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(1, 28);
            this.label29.Margin = new System.Windows.Forms.Padding(1);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 26);
            this.label29.TabIndex = 10;
            this.label29.Text = "cena";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(1, 1);
            this.label30.Margin = new System.Windows.Forms.Padding(1);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(75, 25);
            this.label30.TabIndex = 10;
            this.label30.Text = "nazwa";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola14
            // 
            this.lblNrPola14.BackColor = System.Drawing.Color.Blue;
            this.lblNrPola14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola14.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola14.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola14.Name = "lblNrPola14";
            this.lblNrPola14.Size = new System.Drawing.Size(24, 55);
            this.lblNrPola14.TabIndex = 7;
            this.lblNrPola14.Text = "14";
            this.lblNrPola14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel48
            // 
            this.tableLayoutPanel48.ColumnCount = 2;
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel48.Controls.Add(this.pictureBox46, 1, 1);
            this.tableLayoutPanel48.Controls.Add(this.pictureBox47, 0, 1);
            this.tableLayoutPanel48.Controls.Add(this.pictureBox48, 1, 0);
            this.tableLayoutPanel48.Controls.Add(this.pictureBox49, 0, 0);
            this.tableLayoutPanel48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel48.Location = new System.Drawing.Point(212, 1);
            this.tableLayoutPanel48.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel48.Name = "tableLayoutPanel48";
            this.tableLayoutPanel48.RowCount = 2;
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel48.Size = new System.Drawing.Size(52, 55);
            this.tableLayoutPanel48.TabIndex = 10;
            // 
            // pictureBox46
            // 
            this.pictureBox46.BackColor = System.Drawing.Color.Blue;
            this.pictureBox46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox46.Location = new System.Drawing.Point(27, 28);
            this.pictureBox46.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(24, 26);
            this.pictureBox46.TabIndex = 12;
            this.pictureBox46.TabStop = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.BackColor = System.Drawing.Color.Blue;
            this.pictureBox47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox47.Location = new System.Drawing.Point(1, 28);
            this.pictureBox47.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(24, 26);
            this.pictureBox47.TabIndex = 11;
            this.pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.Color.Blue;
            this.pictureBox48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox48.Location = new System.Drawing.Point(27, 1);
            this.pictureBox48.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(24, 25);
            this.pictureBox48.TabIndex = 10;
            this.pictureBox48.TabStop = false;
            // 
            // pictureBox49
            // 
            this.pictureBox49.BackColor = System.Drawing.Color.Blue;
            this.pictureBox49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox49.Location = new System.Drawing.Point(1, 1);
            this.pictureBox49.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(24, 25);
            this.pictureBox49.TabIndex = 9;
            this.pictureBox49.TabStop = false;
            // 
            // pictureBox50
            // 
            this.pictureBox50.BackColor = System.Drawing.Color.White;
            this.pictureBox50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox50.Location = new System.Drawing.Point(106, 1);
            this.pictureBox50.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(104, 55);
            this.pictureBox50.TabIndex = 9;
            this.pictureBox50.TabStop = false;
            // 
            // tableLayoutPanel43
            // 
            this.tableLayoutPanel43.ColumnCount = 4;
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel43.Controls.Add(this.tableLayoutPanel44, 1, 0);
            this.tableLayoutPanel43.Controls.Add(this.lblNrPola15, 0, 0);
            this.tableLayoutPanel43.Controls.Add(this.tableLayoutPanel45, 3, 0);
            this.tableLayoutPanel43.Controls.Add(this.pictureBox45, 2, 0);
            this.tableLayoutPanel43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel43.Location = new System.Drawing.Point(1, 296);
            this.tableLayoutPanel43.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel43.Name = "tableLayoutPanel43";
            this.tableLayoutPanel43.RowCount = 1;
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel43.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel43.TabIndex = 17;
            // 
            // tableLayoutPanel44
            // 
            this.tableLayoutPanel44.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel44.ColumnCount = 1;
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.Controls.Add(this.label26, 0, 1);
            this.tableLayoutPanel44.Controls.Add(this.label27, 0, 0);
            this.tableLayoutPanel44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel44.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel44.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel44.Name = "tableLayoutPanel44";
            this.tableLayoutPanel44.RowCount = 2;
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel44.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel44.TabIndex = 9;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Silver;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(1, 28);
            this.label26.Margin = new System.Windows.Forms.Padding(1);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(75, 26);
            this.label26.TabIndex = 10;
            this.label26.Text = "cena";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(1, 1);
            this.label27.Margin = new System.Windows.Forms.Padding(1);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(75, 25);
            this.label27.TabIndex = 10;
            this.label27.Text = "nazwa";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola15
            // 
            this.lblNrPola15.BackColor = System.Drawing.Color.Blue;
            this.lblNrPola15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola15.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola15.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola15.Name = "lblNrPola15";
            this.lblNrPola15.Size = new System.Drawing.Size(24, 55);
            this.lblNrPola15.TabIndex = 7;
            this.lblNrPola15.Text = "15";
            this.lblNrPola15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel45
            // 
            this.tableLayoutPanel45.ColumnCount = 2;
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel45.Controls.Add(this.pictureBox41, 1, 1);
            this.tableLayoutPanel45.Controls.Add(this.pictureBox42, 0, 1);
            this.tableLayoutPanel45.Controls.Add(this.pictureBox43, 1, 0);
            this.tableLayoutPanel45.Controls.Add(this.pictureBox44, 0, 0);
            this.tableLayoutPanel45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel45.Location = new System.Drawing.Point(212, 1);
            this.tableLayoutPanel45.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel45.Name = "tableLayoutPanel45";
            this.tableLayoutPanel45.RowCount = 2;
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel45.Size = new System.Drawing.Size(52, 55);
            this.tableLayoutPanel45.TabIndex = 10;
            // 
            // pictureBox41
            // 
            this.pictureBox41.BackColor = System.Drawing.Color.Blue;
            this.pictureBox41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox41.Location = new System.Drawing.Point(27, 28);
            this.pictureBox41.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(24, 26);
            this.pictureBox41.TabIndex = 12;
            this.pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            this.pictureBox42.BackColor = System.Drawing.Color.Blue;
            this.pictureBox42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox42.Location = new System.Drawing.Point(1, 28);
            this.pictureBox42.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(24, 26);
            this.pictureBox42.TabIndex = 11;
            this.pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            this.pictureBox43.BackColor = System.Drawing.Color.Blue;
            this.pictureBox43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox43.Location = new System.Drawing.Point(27, 1);
            this.pictureBox43.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(24, 25);
            this.pictureBox43.TabIndex = 10;
            this.pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            this.pictureBox44.BackColor = System.Drawing.Color.Blue;
            this.pictureBox44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox44.Location = new System.Drawing.Point(1, 1);
            this.pictureBox44.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(24, 25);
            this.pictureBox44.TabIndex = 9;
            this.pictureBox44.TabStop = false;
            // 
            // pictureBox45
            // 
            this.pictureBox45.BackColor = System.Drawing.Color.White;
            this.pictureBox45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox45.Location = new System.Drawing.Point(106, 1);
            this.pictureBox45.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(104, 55);
            this.pictureBox45.TabIndex = 9;
            this.pictureBox45.TabStop = false;
            // 
            // tableLayoutPanel40
            // 
            this.tableLayoutPanel40.ColumnCount = 4;
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel40.Controls.Add(this.tableLayoutPanel41, 1, 0);
            this.tableLayoutPanel40.Controls.Add(this.lblNrPola17, 0, 0);
            this.tableLayoutPanel40.Controls.Add(this.tableLayoutPanel42, 3, 0);
            this.tableLayoutPanel40.Controls.Add(this.pictureBox40, 2, 0);
            this.tableLayoutPanel40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel40.Location = new System.Drawing.Point(1, 178);
            this.tableLayoutPanel40.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel40.Name = "tableLayoutPanel40";
            this.tableLayoutPanel40.RowCount = 1;
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel40.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel40.TabIndex = 17;
            // 
            // tableLayoutPanel41
            // 
            this.tableLayoutPanel41.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel41.ColumnCount = 1;
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.Controls.Add(this.label23, 0, 1);
            this.tableLayoutPanel41.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel41.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel41.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel41.Name = "tableLayoutPanel41";
            this.tableLayoutPanel41.RowCount = 2;
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel41.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel41.TabIndex = 9;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Silver;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(1, 28);
            this.label23.Margin = new System.Windows.Forms.Padding(1);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(75, 26);
            this.label23.TabIndex = 10;
            this.label23.Text = "cena";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(1, 1);
            this.label24.Margin = new System.Windows.Forms.Padding(1);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(75, 25);
            this.label24.TabIndex = 10;
            this.label24.Text = "nazwa";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola17
            // 
            this.lblNrPola17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblNrPola17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola17.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola17.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola17.Name = "lblNrPola17";
            this.lblNrPola17.Size = new System.Drawing.Size(24, 55);
            this.lblNrPola17.TabIndex = 7;
            this.lblNrPola17.Text = "17";
            this.lblNrPola17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel42
            // 
            this.tableLayoutPanel42.ColumnCount = 2;
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel42.Controls.Add(this.pictureBox36, 1, 1);
            this.tableLayoutPanel42.Controls.Add(this.pictureBox37, 0, 1);
            this.tableLayoutPanel42.Controls.Add(this.pictureBox38, 1, 0);
            this.tableLayoutPanel42.Controls.Add(this.pictureBox39, 0, 0);
            this.tableLayoutPanel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel42.Location = new System.Drawing.Point(212, 1);
            this.tableLayoutPanel42.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel42.Name = "tableLayoutPanel42";
            this.tableLayoutPanel42.RowCount = 2;
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel42.Size = new System.Drawing.Size(52, 55);
            this.tableLayoutPanel42.TabIndex = 10;
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox36.Location = new System.Drawing.Point(27, 28);
            this.pictureBox36.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(24, 26);
            this.pictureBox36.TabIndex = 12;
            this.pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox37.Location = new System.Drawing.Point(1, 28);
            this.pictureBox37.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(24, 26);
            this.pictureBox37.TabIndex = 11;
            this.pictureBox37.TabStop = false;
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox38.Location = new System.Drawing.Point(27, 1);
            this.pictureBox38.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(24, 25);
            this.pictureBox38.TabIndex = 10;
            this.pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox39.Location = new System.Drawing.Point(1, 1);
            this.pictureBox39.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(24, 25);
            this.pictureBox39.TabIndex = 9;
            this.pictureBox39.TabStop = false;
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.Color.White;
            this.pictureBox40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox40.Location = new System.Drawing.Point(106, 1);
            this.pictureBox40.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(104, 55);
            this.pictureBox40.TabIndex = 9;
            this.pictureBox40.TabStop = false;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.ColumnCount = 4;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel37.Controls.Add(this.tableLayoutPanel38, 1, 0);
            this.tableLayoutPanel37.Controls.Add(this.lblNrPola19, 0, 0);
            this.tableLayoutPanel37.Controls.Add(this.tableLayoutPanel39, 3, 0);
            this.tableLayoutPanel37.Controls.Add(this.pictureBox35, 2, 0);
            this.tableLayoutPanel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel37.Location = new System.Drawing.Point(1, 60);
            this.tableLayoutPanel37.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 1;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel37.TabIndex = 17;
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel38.ColumnCount = 1;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.label20, 0, 1);
            this.tableLayoutPanel38.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel38.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel38.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 2;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel38.TabIndex = 9;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Silver;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(1, 28);
            this.label20.Margin = new System.Windows.Forms.Padding(1);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 26);
            this.label20.TabIndex = 10;
            this.label20.Text = "cena";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(1, 1);
            this.label21.Margin = new System.Windows.Forms.Padding(1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(75, 25);
            this.label21.TabIndex = 10;
            this.label21.Text = "nazwa";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola19
            // 
            this.lblNrPola19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblNrPola19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola19.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola19.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola19.Name = "lblNrPola19";
            this.lblNrPola19.Size = new System.Drawing.Size(24, 55);
            this.lblNrPola19.TabIndex = 7;
            this.lblNrPola19.Text = "19";
            this.lblNrPola19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel39
            // 
            this.tableLayoutPanel39.ColumnCount = 2;
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel39.Controls.Add(this.pictureBox31, 1, 1);
            this.tableLayoutPanel39.Controls.Add(this.pictureBox32, 0, 1);
            this.tableLayoutPanel39.Controls.Add(this.pictureBox33, 1, 0);
            this.tableLayoutPanel39.Controls.Add(this.pictureBox34, 0, 0);
            this.tableLayoutPanel39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel39.Location = new System.Drawing.Point(212, 1);
            this.tableLayoutPanel39.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel39.Name = "tableLayoutPanel39";
            this.tableLayoutPanel39.RowCount = 2;
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel39.Size = new System.Drawing.Size(52, 55);
            this.tableLayoutPanel39.TabIndex = 10;
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox31.Location = new System.Drawing.Point(27, 28);
            this.pictureBox31.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(24, 26);
            this.pictureBox31.TabIndex = 12;
            this.pictureBox31.TabStop = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox32.Location = new System.Drawing.Point(1, 28);
            this.pictureBox32.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(24, 26);
            this.pictureBox32.TabIndex = 11;
            this.pictureBox32.TabStop = false;
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox33.Location = new System.Drawing.Point(27, 1);
            this.pictureBox33.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(24, 25);
            this.pictureBox33.TabIndex = 10;
            this.pictureBox33.TabStop = false;
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox34.Location = new System.Drawing.Point(1, 1);
            this.pictureBox34.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(24, 25);
            this.pictureBox34.TabIndex = 9;
            this.pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.Color.White;
            this.pictureBox35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox35.Location = new System.Drawing.Point(106, 1);
            this.pictureBox35.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(104, 55);
            this.pictureBox35.TabIndex = 9;
            this.pictureBox35.TabStop = false;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 9;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel54, 2, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel25, 4, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel53, 7, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel82, 1, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel79, 0, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel76, 6, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel5, 8, 0);
            this.tableLayoutPanel34.Controls.Add(this.tableLayoutPanel85, 3, 0);
            this.tableLayoutPanel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(272, 720);
            this.tableLayoutPanel34.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(537, 178);
            this.tableLayoutPanel34.TabIndex = 18;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 1;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.pictureBox30, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel26, 0, 2);
            this.tableLayoutPanel25.Controls.Add(this.pictureBox56, 0, 1);
            this.tableLayoutPanel25.Controls.Add(this.lblNrPola06, 0, 3);
            this.tableLayoutPanel25.Location = new System.Drawing.Point(237, 1);
            this.tableLayoutPanel25.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 4;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel25.TabIndex = 25;
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox30.InitialImage = null;
            this.pictureBox30.Location = new System.Drawing.Point(1, 1);
            this.pictureBox30.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(55, 50);
            this.pictureBox30.TabIndex = 23;
            this.pictureBox30.TabStop = false;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel26.ColumnCount = 1;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Controls.Add(this.label101, 0, 1);
            this.tableLayoutPanel26.Controls.Add(this.label102, 0, 0);
            this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(1, 105);
            this.tableLayoutPanel26.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 2;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel26.TabIndex = 20;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.BackColor = System.Drawing.Color.Silver;
            this.label101.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label101.Location = new System.Drawing.Point(1, 26);
            this.label101.Margin = new System.Windows.Forms.Padding(1);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(53, 23);
            this.label101.TabIndex = 10;
            this.label101.Text = "cena";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label102.Location = new System.Drawing.Point(1, 1);
            this.label102.Margin = new System.Windows.Forms.Padding(1);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(53, 23);
            this.label102.TabIndex = 10;
            this.label102.Text = "nazwa";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.Color.White;
            this.pictureBox56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox56.Location = new System.Drawing.Point(1, 53);
            this.pictureBox56.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(55, 50);
            this.pictureBox56.TabIndex = 19;
            this.pictureBox56.TabStop = false;
            // 
            // lblNrPola06
            // 
            this.lblNrPola06.BackColor = System.Drawing.Color.LightGray;
            this.lblNrPola06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola06.Location = new System.Drawing.Point(1, 157);
            this.lblNrPola06.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola06.Name = "lblNrPola06";
            this.lblNrPola06.Size = new System.Drawing.Size(55, 17);
            this.lblNrPola06.TabIndex = 18;
            this.lblNrPola06.Text = "6";
            this.lblNrPola06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(1, 1);
            this.label1.Margin = new System.Windows.Forms.Padding(1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 156);
            this.label1.TabIndex = 20;
            this.label1.Text = "?";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel82
            // 
            this.tableLayoutPanel82.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel82.ColumnCount = 1;
            this.tableLayoutPanel82.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel82.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel82.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel82.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel82.Controls.Add(this.lblNrPola09, 0, 3);
            this.tableLayoutPanel82.Controls.Add(this.tableLayoutPanel83, 0, 2);
            this.tableLayoutPanel82.Controls.Add(this.pictureBox121, 0, 1);
            this.tableLayoutPanel82.Controls.Add(this.tableLayoutPanel84, 0, 0);
            this.tableLayoutPanel82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel82.Location = new System.Drawing.Point(60, 1);
            this.tableLayoutPanel82.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel82.Name = "tableLayoutPanel82";
            this.tableLayoutPanel82.RowCount = 4;
            this.tableLayoutPanel82.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel82.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel82.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel82.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel82.Size = new System.Drawing.Size(57, 176);
            this.tableLayoutPanel82.TabIndex = 19;
            // 
            // lblNrPola09
            // 
            this.lblNrPola09.BackColor = System.Drawing.Color.Red;
            this.lblNrPola09.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola09.Location = new System.Drawing.Point(2, 158);
            this.lblNrPola09.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola09.Name = "lblNrPola09";
            this.lblNrPola09.Size = new System.Drawing.Size(53, 16);
            this.lblNrPola09.TabIndex = 18;
            this.lblNrPola09.Text = "9";
            this.lblNrPola09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel83
            // 
            this.tableLayoutPanel83.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel83.ColumnCount = 1;
            this.tableLayoutPanel83.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel83.Controls.Add(this.label75, 0, 1);
            this.tableLayoutPanel83.Controls.Add(this.label76, 0, 0);
            this.tableLayoutPanel83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel83.Location = new System.Drawing.Point(2, 106);
            this.tableLayoutPanel83.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel83.Name = "tableLayoutPanel83";
            this.tableLayoutPanel83.RowCount = 2;
            this.tableLayoutPanel83.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel83.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel83.Size = new System.Drawing.Size(53, 49);
            this.tableLayoutPanel83.TabIndex = 20;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.Silver;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Location = new System.Drawing.Point(1, 25);
            this.label75.Margin = new System.Windows.Forms.Padding(1);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(51, 23);
            this.label75.TabIndex = 10;
            this.label75.Text = "cena";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(1, 1);
            this.label76.Margin = new System.Windows.Forms.Padding(1);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(51, 22);
            this.label76.TabIndex = 10;
            this.label76.Text = "nazwa";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox121
            // 
            this.pictureBox121.BackColor = System.Drawing.Color.White;
            this.pictureBox121.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox121.Location = new System.Drawing.Point(2, 37);
            this.pictureBox121.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox121.Name = "pictureBox121";
            this.pictureBox121.Size = new System.Drawing.Size(53, 66);
            this.pictureBox121.TabIndex = 19;
            this.pictureBox121.TabStop = false;
            // 
            // tableLayoutPanel84
            // 
            this.tableLayoutPanel84.ColumnCount = 2;
            this.tableLayoutPanel84.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel84.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel84.Controls.Add(this.pictureBox122, 1, 1);
            this.tableLayoutPanel84.Controls.Add(this.pictureBox123, 0, 1);
            this.tableLayoutPanel84.Controls.Add(this.pictureBox124, 1, 0);
            this.tableLayoutPanel84.Controls.Add(this.pictureBox125, 0, 0);
            this.tableLayoutPanel84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel84.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel84.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel84.Name = "tableLayoutPanel84";
            this.tableLayoutPanel84.RowCount = 2;
            this.tableLayoutPanel84.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel84.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel84.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel84.Size = new System.Drawing.Size(53, 32);
            this.tableLayoutPanel84.TabIndex = 18;
            // 
            // pictureBox122
            // 
            this.pictureBox122.BackColor = System.Drawing.Color.Red;
            this.pictureBox122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox122.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox122.Location = new System.Drawing.Point(27, 17);
            this.pictureBox122.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox122.Name = "pictureBox122";
            this.pictureBox122.Size = new System.Drawing.Size(25, 14);
            this.pictureBox122.TabIndex = 12;
            this.pictureBox122.TabStop = false;
            // 
            // pictureBox123
            // 
            this.pictureBox123.BackColor = System.Drawing.Color.Red;
            this.pictureBox123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox123.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox123.Location = new System.Drawing.Point(1, 17);
            this.pictureBox123.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox123.Name = "pictureBox123";
            this.pictureBox123.Size = new System.Drawing.Size(24, 14);
            this.pictureBox123.TabIndex = 11;
            this.pictureBox123.TabStop = false;
            // 
            // pictureBox124
            // 
            this.pictureBox124.BackColor = System.Drawing.Color.Red;
            this.pictureBox124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox124.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox124.Location = new System.Drawing.Point(27, 1);
            this.pictureBox124.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox124.Name = "pictureBox124";
            this.pictureBox124.Size = new System.Drawing.Size(25, 14);
            this.pictureBox124.TabIndex = 10;
            this.pictureBox124.TabStop = false;
            // 
            // pictureBox125
            // 
            this.pictureBox125.BackColor = System.Drawing.Color.Red;
            this.pictureBox125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox125.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox125.Location = new System.Drawing.Point(1, 1);
            this.pictureBox125.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox125.Name = "pictureBox125";
            this.pictureBox125.Size = new System.Drawing.Size(24, 14);
            this.pictureBox125.TabIndex = 9;
            this.pictureBox125.TabStop = false;
            // 
            // tableLayoutPanel79
            // 
            this.tableLayoutPanel79.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel79.ColumnCount = 1;
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel79.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel79.Controls.Add(this.lblNrPola10, 0, 3);
            this.tableLayoutPanel79.Controls.Add(this.tableLayoutPanel80, 0, 2);
            this.tableLayoutPanel79.Controls.Add(this.pictureBox116, 0, 1);
            this.tableLayoutPanel79.Controls.Add(this.tableLayoutPanel81, 0, 0);
            this.tableLayoutPanel79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel79.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel79.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel79.Name = "tableLayoutPanel79";
            this.tableLayoutPanel79.RowCount = 4;
            this.tableLayoutPanel79.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel79.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel79.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel79.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel79.Size = new System.Drawing.Size(57, 176);
            this.tableLayoutPanel79.TabIndex = 19;
            // 
            // lblNrPola10
            // 
            this.lblNrPola10.BackColor = System.Drawing.Color.Red;
            this.lblNrPola10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola10.Location = new System.Drawing.Point(2, 158);
            this.lblNrPola10.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola10.Name = "lblNrPola10";
            this.lblNrPola10.Size = new System.Drawing.Size(53, 16);
            this.lblNrPola10.TabIndex = 18;
            this.lblNrPola10.Text = "10";
            this.lblNrPola10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel80
            // 
            this.tableLayoutPanel80.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel80.ColumnCount = 1;
            this.tableLayoutPanel80.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel80.Controls.Add(this.label72, 0, 1);
            this.tableLayoutPanel80.Controls.Add(this.label73, 0, 0);
            this.tableLayoutPanel80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel80.Location = new System.Drawing.Point(2, 106);
            this.tableLayoutPanel80.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel80.Name = "tableLayoutPanel80";
            this.tableLayoutPanel80.RowCount = 2;
            this.tableLayoutPanel80.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel80.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel80.Size = new System.Drawing.Size(53, 49);
            this.tableLayoutPanel80.TabIndex = 20;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.Silver;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(1, 25);
            this.label72.Margin = new System.Windows.Forms.Padding(1);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(51, 23);
            this.label72.TabIndex = 10;
            this.label72.Text = "cena";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(1, 1);
            this.label73.Margin = new System.Windows.Forms.Padding(1);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(51, 22);
            this.label73.TabIndex = 10;
            this.label73.Text = "nazwa";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox116
            // 
            this.pictureBox116.BackColor = System.Drawing.Color.White;
            this.pictureBox116.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox116.Location = new System.Drawing.Point(2, 37);
            this.pictureBox116.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox116.Name = "pictureBox116";
            this.pictureBox116.Size = new System.Drawing.Size(53, 66);
            this.pictureBox116.TabIndex = 19;
            this.pictureBox116.TabStop = false;
            // 
            // tableLayoutPanel81
            // 
            this.tableLayoutPanel81.ColumnCount = 2;
            this.tableLayoutPanel81.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel81.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel81.Controls.Add(this.pictureBox117, 1, 1);
            this.tableLayoutPanel81.Controls.Add(this.pictureBox118, 0, 1);
            this.tableLayoutPanel81.Controls.Add(this.pictureBox119, 1, 0);
            this.tableLayoutPanel81.Controls.Add(this.pictureBox120, 0, 0);
            this.tableLayoutPanel81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel81.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel81.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel81.Name = "tableLayoutPanel81";
            this.tableLayoutPanel81.RowCount = 2;
            this.tableLayoutPanel81.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel81.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel81.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel81.Size = new System.Drawing.Size(53, 32);
            this.tableLayoutPanel81.TabIndex = 18;
            // 
            // pictureBox117
            // 
            this.pictureBox117.BackColor = System.Drawing.Color.Red;
            this.pictureBox117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox117.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox117.Location = new System.Drawing.Point(27, 17);
            this.pictureBox117.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox117.Name = "pictureBox117";
            this.pictureBox117.Size = new System.Drawing.Size(25, 14);
            this.pictureBox117.TabIndex = 12;
            this.pictureBox117.TabStop = false;
            // 
            // pictureBox118
            // 
            this.pictureBox118.BackColor = System.Drawing.Color.Red;
            this.pictureBox118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox118.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox118.Location = new System.Drawing.Point(1, 17);
            this.pictureBox118.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox118.Name = "pictureBox118";
            this.pictureBox118.Size = new System.Drawing.Size(24, 14);
            this.pictureBox118.TabIndex = 11;
            this.pictureBox118.TabStop = false;
            // 
            // pictureBox119
            // 
            this.pictureBox119.BackColor = System.Drawing.Color.Red;
            this.pictureBox119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox119.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox119.Location = new System.Drawing.Point(27, 1);
            this.pictureBox119.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox119.Name = "pictureBox119";
            this.pictureBox119.Size = new System.Drawing.Size(25, 14);
            this.pictureBox119.TabIndex = 10;
            this.pictureBox119.TabStop = false;
            // 
            // pictureBox120
            // 
            this.pictureBox120.BackColor = System.Drawing.Color.Red;
            this.pictureBox120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox120.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox120.Location = new System.Drawing.Point(1, 1);
            this.pictureBox120.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox120.Name = "pictureBox120";
            this.pictureBox120.Size = new System.Drawing.Size(24, 14);
            this.pictureBox120.TabIndex = 9;
            this.pictureBox120.TabStop = false;
            // 
            // tableLayoutPanel76
            // 
            this.tableLayoutPanel76.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel76.ColumnCount = 1;
            this.tableLayoutPanel76.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel76.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel76.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel76.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel76.Controls.Add(this.lblNrPola04, 0, 3);
            this.tableLayoutPanel76.Controls.Add(this.tableLayoutPanel77, 0, 2);
            this.tableLayoutPanel76.Controls.Add(this.pictureBox111, 0, 1);
            this.tableLayoutPanel76.Controls.Add(this.tableLayoutPanel78, 0, 0);
            this.tableLayoutPanel76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel76.Location = new System.Drawing.Point(355, 1);
            this.tableLayoutPanel76.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel76.Name = "tableLayoutPanel76";
            this.tableLayoutPanel76.RowCount = 4;
            this.tableLayoutPanel76.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel76.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel76.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel76.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel76.Size = new System.Drawing.Size(57, 176);
            this.tableLayoutPanel76.TabIndex = 19;
            // 
            // lblNrPola04
            // 
            this.lblNrPola04.BackColor = System.Drawing.Color.Yellow;
            this.lblNrPola04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola04.Location = new System.Drawing.Point(2, 158);
            this.lblNrPola04.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola04.Name = "lblNrPola04";
            this.lblNrPola04.Size = new System.Drawing.Size(53, 16);
            this.lblNrPola04.TabIndex = 18;
            this.lblNrPola04.Text = "4";
            this.lblNrPola04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel77
            // 
            this.tableLayoutPanel77.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel77.ColumnCount = 1;
            this.tableLayoutPanel77.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel77.Controls.Add(this.label69, 0, 1);
            this.tableLayoutPanel77.Controls.Add(this.label70, 0, 0);
            this.tableLayoutPanel77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel77.Location = new System.Drawing.Point(2, 106);
            this.tableLayoutPanel77.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel77.Name = "tableLayoutPanel77";
            this.tableLayoutPanel77.RowCount = 2;
            this.tableLayoutPanel77.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel77.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel77.Size = new System.Drawing.Size(53, 49);
            this.tableLayoutPanel77.TabIndex = 20;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Silver;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Location = new System.Drawing.Point(1, 25);
            this.label69.Margin = new System.Windows.Forms.Padding(1);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(51, 23);
            this.label69.TabIndex = 10;
            this.label69.Text = "cena";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(1, 1);
            this.label70.Margin = new System.Windows.Forms.Padding(1);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(51, 22);
            this.label70.TabIndex = 10;
            this.label70.Text = "nazwa";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox111
            // 
            this.pictureBox111.BackColor = System.Drawing.Color.White;
            this.pictureBox111.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox111.Location = new System.Drawing.Point(2, 37);
            this.pictureBox111.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox111.Name = "pictureBox111";
            this.pictureBox111.Size = new System.Drawing.Size(53, 66);
            this.pictureBox111.TabIndex = 19;
            this.pictureBox111.TabStop = false;
            // 
            // tableLayoutPanel78
            // 
            this.tableLayoutPanel78.ColumnCount = 2;
            this.tableLayoutPanel78.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel78.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel78.Controls.Add(this.pictureBox112, 1, 1);
            this.tableLayoutPanel78.Controls.Add(this.pictureBox113, 0, 1);
            this.tableLayoutPanel78.Controls.Add(this.pictureBox114, 1, 0);
            this.tableLayoutPanel78.Controls.Add(this.pictureBox115, 0, 0);
            this.tableLayoutPanel78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel78.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel78.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel78.Name = "tableLayoutPanel78";
            this.tableLayoutPanel78.RowCount = 2;
            this.tableLayoutPanel78.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel78.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel78.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel78.Size = new System.Drawing.Size(53, 32);
            this.tableLayoutPanel78.TabIndex = 18;
            // 
            // pictureBox112
            // 
            this.pictureBox112.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox112.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox112.Location = new System.Drawing.Point(27, 17);
            this.pictureBox112.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox112.Name = "pictureBox112";
            this.pictureBox112.Size = new System.Drawing.Size(25, 14);
            this.pictureBox112.TabIndex = 12;
            this.pictureBox112.TabStop = false;
            // 
            // pictureBox113
            // 
            this.pictureBox113.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox113.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox113.Location = new System.Drawing.Point(1, 17);
            this.pictureBox113.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox113.Name = "pictureBox113";
            this.pictureBox113.Size = new System.Drawing.Size(24, 14);
            this.pictureBox113.TabIndex = 11;
            this.pictureBox113.TabStop = false;
            // 
            // pictureBox114
            // 
            this.pictureBox114.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox114.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox114.Location = new System.Drawing.Point(27, 1);
            this.pictureBox114.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox114.Name = "pictureBox114";
            this.pictureBox114.Size = new System.Drawing.Size(25, 14);
            this.pictureBox114.TabIndex = 10;
            this.pictureBox114.TabStop = false;
            // 
            // pictureBox115
            // 
            this.pictureBox115.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox115.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox115.Location = new System.Drawing.Point(1, 1);
            this.pictureBox115.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox115.Name = "pictureBox115";
            this.pictureBox115.Size = new System.Drawing.Size(24, 14);
            this.pictureBox115.TabIndex = 9;
            this.pictureBox115.TabStop = false;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Controls.Add(this.lblNrPola02, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel31, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.pictureBox74, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(472, 0);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 4;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(65, 178);
            this.tableLayoutPanel5.TabIndex = 19;
            // 
            // lblNrPola02
            // 
            this.lblNrPola02.BackColor = System.Drawing.Color.Yellow;
            this.lblNrPola02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola02.Location = new System.Drawing.Point(2, 159);
            this.lblNrPola02.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola02.Name = "lblNrPola02";
            this.lblNrPola02.Size = new System.Drawing.Size(61, 17);
            this.lblNrPola02.TabIndex = 18;
            this.lblNrPola02.Text = "2";
            this.lblNrPola02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.Controls.Add(this.label43, 0, 1);
            this.tableLayoutPanel31.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(2, 107);
            this.tableLayoutPanel31.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 2;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(61, 49);
            this.tableLayoutPanel31.TabIndex = 20;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Silver;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(1, 25);
            this.label43.Margin = new System.Windows.Forms.Padding(1);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(59, 23);
            this.label43.TabIndex = 10;
            this.label43.Text = "cena";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(1, 1);
            this.label44.Margin = new System.Windows.Forms.Padding(1);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(59, 22);
            this.label44.TabIndex = 10;
            this.label44.Text = "nazwa";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox74
            // 
            this.pictureBox74.BackColor = System.Drawing.Color.White;
            this.pictureBox74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox74.Location = new System.Drawing.Point(2, 37);
            this.pictureBox74.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(61, 67);
            this.pictureBox74.TabIndex = 19;
            this.pictureBox74.TabStop = false;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.Controls.Add(this.pictureBox66, 1, 1);
            this.tableLayoutPanel27.Controls.Add(this.pictureBox67, 0, 1);
            this.tableLayoutPanel27.Controls.Add(this.pictureBox68, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.pictureBox69, 0, 0);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel27.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 2;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(61, 32);
            this.tableLayoutPanel27.TabIndex = 18;
            // 
            // pictureBox66
            // 
            this.pictureBox66.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox66.Location = new System.Drawing.Point(31, 17);
            this.pictureBox66.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(29, 14);
            this.pictureBox66.TabIndex = 12;
            this.pictureBox66.TabStop = false;
            // 
            // pictureBox67
            // 
            this.pictureBox67.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox67.Location = new System.Drawing.Point(1, 17);
            this.pictureBox67.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(28, 14);
            this.pictureBox67.TabIndex = 11;
            this.pictureBox67.TabStop = false;
            // 
            // pictureBox68
            // 
            this.pictureBox68.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox68.Location = new System.Drawing.Point(31, 1);
            this.pictureBox68.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(29, 14);
            this.pictureBox68.TabIndex = 10;
            this.pictureBox68.TabStop = false;
            // 
            // pictureBox69
            // 
            this.pictureBox69.BackColor = System.Drawing.Color.Yellow;
            this.pictureBox69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox69.Location = new System.Drawing.Point(1, 1);
            this.pictureBox69.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(28, 14);
            this.pictureBox69.TabIndex = 9;
            this.pictureBox69.TabStop = false;
            // 
            // tableLayoutPanel85
            // 
            this.tableLayoutPanel85.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel85.ColumnCount = 1;
            this.tableLayoutPanel85.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel85.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel85.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel85.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel85.Controls.Add(this.lblNrPola07, 0, 3);
            this.tableLayoutPanel85.Controls.Add(this.tableLayoutPanel86, 0, 2);
            this.tableLayoutPanel85.Controls.Add(this.pictureBox126, 0, 1);
            this.tableLayoutPanel85.Controls.Add(this.tableLayoutPanel87, 0, 0);
            this.tableLayoutPanel85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel85.Location = new System.Drawing.Point(178, 1);
            this.tableLayoutPanel85.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel85.Name = "tableLayoutPanel85";
            this.tableLayoutPanel85.RowCount = 4;
            this.tableLayoutPanel85.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel85.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel85.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel85.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel85.Size = new System.Drawing.Size(57, 176);
            this.tableLayoutPanel85.TabIndex = 19;
            // 
            // lblNrPola07
            // 
            this.lblNrPola07.BackColor = System.Drawing.Color.Red;
            this.lblNrPola07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola07.Location = new System.Drawing.Point(2, 158);
            this.lblNrPola07.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola07.Name = "lblNrPola07";
            this.lblNrPola07.Size = new System.Drawing.Size(53, 16);
            this.lblNrPola07.TabIndex = 18;
            this.lblNrPola07.Text = "7";
            this.lblNrPola07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel86
            // 
            this.tableLayoutPanel86.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel86.ColumnCount = 1;
            this.tableLayoutPanel86.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel86.Controls.Add(this.label78, 0, 1);
            this.tableLayoutPanel86.Controls.Add(this.label79, 0, 0);
            this.tableLayoutPanel86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel86.Location = new System.Drawing.Point(2, 106);
            this.tableLayoutPanel86.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel86.Name = "tableLayoutPanel86";
            this.tableLayoutPanel86.RowCount = 2;
            this.tableLayoutPanel86.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel86.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel86.Size = new System.Drawing.Size(53, 49);
            this.tableLayoutPanel86.TabIndex = 20;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.Silver;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(1, 25);
            this.label78.Margin = new System.Windows.Forms.Padding(1);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(51, 23);
            this.label78.TabIndex = 10;
            this.label78.Text = "cena";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(1, 1);
            this.label79.Margin = new System.Windows.Forms.Padding(1);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(51, 22);
            this.label79.TabIndex = 10;
            this.label79.Text = "nazwa";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox126
            // 
            this.pictureBox126.BackColor = System.Drawing.Color.White;
            this.pictureBox126.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox126.Location = new System.Drawing.Point(2, 37);
            this.pictureBox126.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox126.Name = "pictureBox126";
            this.pictureBox126.Size = new System.Drawing.Size(53, 66);
            this.pictureBox126.TabIndex = 19;
            this.pictureBox126.TabStop = false;
            // 
            // tableLayoutPanel87
            // 
            this.tableLayoutPanel87.ColumnCount = 2;
            this.tableLayoutPanel87.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel87.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel87.Controls.Add(this.pictureBox127, 1, 1);
            this.tableLayoutPanel87.Controls.Add(this.pictureBox128, 0, 1);
            this.tableLayoutPanel87.Controls.Add(this.pictureBox129, 1, 0);
            this.tableLayoutPanel87.Controls.Add(this.pictureBox130, 0, 0);
            this.tableLayoutPanel87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel87.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel87.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel87.Name = "tableLayoutPanel87";
            this.tableLayoutPanel87.RowCount = 2;
            this.tableLayoutPanel87.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel87.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel87.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel87.Size = new System.Drawing.Size(53, 32);
            this.tableLayoutPanel87.TabIndex = 18;
            // 
            // pictureBox127
            // 
            this.pictureBox127.BackColor = System.Drawing.Color.Red;
            this.pictureBox127.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox127.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox127.Location = new System.Drawing.Point(27, 17);
            this.pictureBox127.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox127.Name = "pictureBox127";
            this.pictureBox127.Size = new System.Drawing.Size(25, 14);
            this.pictureBox127.TabIndex = 12;
            this.pictureBox127.TabStop = false;
            // 
            // pictureBox128
            // 
            this.pictureBox128.BackColor = System.Drawing.Color.Red;
            this.pictureBox128.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox128.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox128.Location = new System.Drawing.Point(1, 17);
            this.pictureBox128.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox128.Name = "pictureBox128";
            this.pictureBox128.Size = new System.Drawing.Size(24, 14);
            this.pictureBox128.TabIndex = 11;
            this.pictureBox128.TabStop = false;
            // 
            // pictureBox129
            // 
            this.pictureBox129.BackColor = System.Drawing.Color.Red;
            this.pictureBox129.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox129.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox129.Location = new System.Drawing.Point(27, 1);
            this.pictureBox129.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox129.Name = "pictureBox129";
            this.pictureBox129.Size = new System.Drawing.Size(25, 14);
            this.pictureBox129.TabIndex = 10;
            this.pictureBox129.TabStop = false;
            // 
            // pictureBox130
            // 
            this.pictureBox130.BackColor = System.Drawing.Color.Red;
            this.pictureBox130.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox130.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox130.Location = new System.Drawing.Point(1, 1);
            this.pictureBox130.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox130.Name = "pictureBox130";
            this.pictureBox130.Size = new System.Drawing.Size(24, 14);
            this.pictureBox130.TabIndex = 9;
            this.pictureBox130.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(1, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 158);
            this.label6.TabIndex = 21;
            this.label6.Text = "?";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.ColumnCount = 9;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel10, 4, 0);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel73, 8, 0);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel52, 1, 0);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel70, 6, 0);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel67, 5, 0);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel64, 3, 0);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel61, 2, 0);
            this.tableLayoutPanel33.Controls.Add(this.tableLayoutPanel58, 0, 0);
            this.tableLayoutPanel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(272, 2);
            this.tableLayoutPanel33.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 1;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(537, 177);
            this.tableLayoutPanel33.TabIndex = 17;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.pictureBox13, 0, 3);
            this.tableLayoutPanel10.Controls.Add(this.lblNrPola26, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel13, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.pictureBox14, 0, 2);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(237, 1);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 4;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel10.TabIndex = 23;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox13.InitialImage = null;
            this.pictureBox13.Location = new System.Drawing.Point(1, 122);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(55, 52);
            this.pictureBox13.TabIndex = 23;
            this.pictureBox13.TabStop = false;
            // 
            // lblNrPola26
            // 
            this.lblNrPola26.BackColor = System.Drawing.Color.LightGray;
            this.lblNrPola26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola26.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola26.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola26.Name = "lblNrPola26";
            this.lblNrPola26.Size = new System.Drawing.Size(55, 15);
            this.lblNrPola26.TabIndex = 18;
            this.lblNrPola26.Text = "26";
            this.lblNrPola26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.label39, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel13.TabIndex = 20;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Silver;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(1, 26);
            this.label39.Margin = new System.Windows.Forms.Padding(1);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(53, 23);
            this.label39.TabIndex = 10;
            this.label39.Text = "cena";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(1, 1);
            this.label40.Margin = new System.Windows.Forms.Padding(1);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(53, 23);
            this.label40.TabIndex = 10;
            this.label40.Text = "nazwa";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.White;
            this.pictureBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox14.Location = new System.Drawing.Point(1, 70);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(55, 50);
            this.pictureBox14.TabIndex = 19;
            this.pictureBox14.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(1, 18);
            this.label5.Margin = new System.Windows.Forms.Padding(1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 156);
            this.label5.TabIndex = 21;
            this.label5.Text = "?";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel73
            // 
            this.tableLayoutPanel73.ColumnCount = 1;
            this.tableLayoutPanel73.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel73.Controls.Add(this.lblNrPola30, 0, 0);
            this.tableLayoutPanel73.Controls.Add(this.tableLayoutPanel74, 0, 1);
            this.tableLayoutPanel73.Controls.Add(this.tableLayoutPanel75, 0, 3);
            this.tableLayoutPanel73.Controls.Add(this.pictureBox110, 0, 2);
            this.tableLayoutPanel73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel73.Location = new System.Drawing.Point(473, 1);
            this.tableLayoutPanel73.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel73.Name = "tableLayoutPanel73";
            this.tableLayoutPanel73.RowCount = 4;
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel73.Size = new System.Drawing.Size(63, 175);
            this.tableLayoutPanel73.TabIndex = 19;
            // 
            // lblNrPola30
            // 
            this.lblNrPola30.BackColor = System.Drawing.Color.Purple;
            this.lblNrPola30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola30.ForeColor = System.Drawing.Color.White;
            this.lblNrPola30.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola30.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola30.Name = "lblNrPola30";
            this.lblNrPola30.Size = new System.Drawing.Size(61, 15);
            this.lblNrPola30.TabIndex = 18;
            this.lblNrPola30.Text = "30";
            this.lblNrPola30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel74
            // 
            this.tableLayoutPanel74.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel74.ColumnCount = 1;
            this.tableLayoutPanel74.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel74.Controls.Add(this.label66, 0, 1);
            this.tableLayoutPanel74.Controls.Add(this.label67, 0, 0);
            this.tableLayoutPanel74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel74.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel74.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel74.Name = "tableLayoutPanel74";
            this.tableLayoutPanel74.RowCount = 2;
            this.tableLayoutPanel74.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel74.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel74.Size = new System.Drawing.Size(61, 50);
            this.tableLayoutPanel74.TabIndex = 20;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.Silver;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(1, 26);
            this.label66.Margin = new System.Windows.Forms.Padding(1);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(59, 23);
            this.label66.TabIndex = 10;
            this.label66.Text = "cena";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(1, 1);
            this.label67.Margin = new System.Windows.Forms.Padding(1);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(59, 23);
            this.label67.TabIndex = 10;
            this.label67.Text = "nazwa";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel75
            // 
            this.tableLayoutPanel75.ColumnCount = 2;
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel75.Controls.Add(this.pictureBox106, 1, 1);
            this.tableLayoutPanel75.Controls.Add(this.pictureBox107, 0, 1);
            this.tableLayoutPanel75.Controls.Add(this.pictureBox108, 1, 0);
            this.tableLayoutPanel75.Controls.Add(this.pictureBox109, 0, 0);
            this.tableLayoutPanel75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel75.Location = new System.Drawing.Point(1, 140);
            this.tableLayoutPanel75.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel75.Name = "tableLayoutPanel75";
            this.tableLayoutPanel75.RowCount = 2;
            this.tableLayoutPanel75.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel75.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel75.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel75.Size = new System.Drawing.Size(61, 34);
            this.tableLayoutPanel75.TabIndex = 18;
            // 
            // pictureBox106
            // 
            this.pictureBox106.BackColor = System.Drawing.Color.Purple;
            this.pictureBox106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox106.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox106.Location = new System.Drawing.Point(31, 18);
            this.pictureBox106.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox106.Name = "pictureBox106";
            this.pictureBox106.Size = new System.Drawing.Size(29, 15);
            this.pictureBox106.TabIndex = 12;
            this.pictureBox106.TabStop = false;
            // 
            // pictureBox107
            // 
            this.pictureBox107.BackColor = System.Drawing.Color.Purple;
            this.pictureBox107.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox107.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox107.Location = new System.Drawing.Point(1, 18);
            this.pictureBox107.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox107.Name = "pictureBox107";
            this.pictureBox107.Size = new System.Drawing.Size(28, 15);
            this.pictureBox107.TabIndex = 11;
            this.pictureBox107.TabStop = false;
            // 
            // pictureBox108
            // 
            this.pictureBox108.BackColor = System.Drawing.Color.Purple;
            this.pictureBox108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox108.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox108.Location = new System.Drawing.Point(31, 1);
            this.pictureBox108.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox108.Name = "pictureBox108";
            this.pictureBox108.Size = new System.Drawing.Size(29, 15);
            this.pictureBox108.TabIndex = 10;
            this.pictureBox108.TabStop = false;
            // 
            // pictureBox109
            // 
            this.pictureBox109.BackColor = System.Drawing.Color.Purple;
            this.pictureBox109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox109.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox109.Location = new System.Drawing.Point(1, 1);
            this.pictureBox109.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox109.Name = "pictureBox109";
            this.pictureBox109.Size = new System.Drawing.Size(28, 15);
            this.pictureBox109.TabIndex = 9;
            this.pictureBox109.TabStop = false;
            // 
            // pictureBox110
            // 
            this.pictureBox110.BackColor = System.Drawing.Color.White;
            this.pictureBox110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox110.Location = new System.Drawing.Point(1, 70);
            this.pictureBox110.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox110.Name = "pictureBox110";
            this.pictureBox110.Size = new System.Drawing.Size(61, 68);
            this.pictureBox110.TabIndex = 19;
            this.pictureBox110.TabStop = false;
            // 
            // tableLayoutPanel70
            // 
            this.tableLayoutPanel70.ColumnCount = 1;
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel70.Controls.Add(this.lblNrPola28, 0, 0);
            this.tableLayoutPanel70.Controls.Add(this.tableLayoutPanel71, 0, 1);
            this.tableLayoutPanel70.Controls.Add(this.tableLayoutPanel72, 0, 3);
            this.tableLayoutPanel70.Controls.Add(this.pictureBox105, 0, 2);
            this.tableLayoutPanel70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel70.Location = new System.Drawing.Point(355, 1);
            this.tableLayoutPanel70.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel70.Name = "tableLayoutPanel70";
            this.tableLayoutPanel70.RowCount = 4;
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel70.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel70.TabIndex = 19;
            // 
            // lblNrPola28
            // 
            this.lblNrPola28.BackColor = System.Drawing.Color.Purple;
            this.lblNrPola28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola28.ForeColor = System.Drawing.Color.White;
            this.lblNrPola28.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola28.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola28.Name = "lblNrPola28";
            this.lblNrPola28.Size = new System.Drawing.Size(55, 15);
            this.lblNrPola28.TabIndex = 18;
            this.lblNrPola28.Text = "28";
            this.lblNrPola28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel71
            // 
            this.tableLayoutPanel71.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel71.ColumnCount = 1;
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel71.Controls.Add(this.label63, 0, 1);
            this.tableLayoutPanel71.Controls.Add(this.label64, 0, 0);
            this.tableLayoutPanel71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel71.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel71.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel71.Name = "tableLayoutPanel71";
            this.tableLayoutPanel71.RowCount = 2;
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel71.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel71.TabIndex = 20;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.Silver;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Location = new System.Drawing.Point(1, 26);
            this.label63.Margin = new System.Windows.Forms.Padding(1);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(53, 23);
            this.label63.TabIndex = 10;
            this.label63.Text = "cena";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Location = new System.Drawing.Point(1, 1);
            this.label64.Margin = new System.Windows.Forms.Padding(1);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(53, 23);
            this.label64.TabIndex = 10;
            this.label64.Text = "nazwa";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel72
            // 
            this.tableLayoutPanel72.ColumnCount = 2;
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel72.Controls.Add(this.pictureBox101, 1, 1);
            this.tableLayoutPanel72.Controls.Add(this.pictureBox102, 0, 1);
            this.tableLayoutPanel72.Controls.Add(this.pictureBox103, 1, 0);
            this.tableLayoutPanel72.Controls.Add(this.pictureBox104, 0, 0);
            this.tableLayoutPanel72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel72.Location = new System.Drawing.Point(1, 140);
            this.tableLayoutPanel72.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel72.Name = "tableLayoutPanel72";
            this.tableLayoutPanel72.RowCount = 2;
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel72.Size = new System.Drawing.Size(55, 34);
            this.tableLayoutPanel72.TabIndex = 18;
            // 
            // pictureBox101
            // 
            this.pictureBox101.BackColor = System.Drawing.Color.Purple;
            this.pictureBox101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox101.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox101.Location = new System.Drawing.Point(28, 18);
            this.pictureBox101.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox101.Name = "pictureBox101";
            this.pictureBox101.Size = new System.Drawing.Size(26, 15);
            this.pictureBox101.TabIndex = 12;
            this.pictureBox101.TabStop = false;
            // 
            // pictureBox102
            // 
            this.pictureBox102.BackColor = System.Drawing.Color.Purple;
            this.pictureBox102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox102.Location = new System.Drawing.Point(1, 18);
            this.pictureBox102.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox102.Name = "pictureBox102";
            this.pictureBox102.Size = new System.Drawing.Size(25, 15);
            this.pictureBox102.TabIndex = 11;
            this.pictureBox102.TabStop = false;
            // 
            // pictureBox103
            // 
            this.pictureBox103.BackColor = System.Drawing.Color.Purple;
            this.pictureBox103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox103.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox103.Location = new System.Drawing.Point(28, 1);
            this.pictureBox103.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox103.Name = "pictureBox103";
            this.pictureBox103.Size = new System.Drawing.Size(26, 15);
            this.pictureBox103.TabIndex = 10;
            this.pictureBox103.TabStop = false;
            // 
            // pictureBox104
            // 
            this.pictureBox104.BackColor = System.Drawing.Color.Purple;
            this.pictureBox104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox104.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox104.Location = new System.Drawing.Point(1, 1);
            this.pictureBox104.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox104.Name = "pictureBox104";
            this.pictureBox104.Size = new System.Drawing.Size(25, 15);
            this.pictureBox104.TabIndex = 9;
            this.pictureBox104.TabStop = false;
            // 
            // pictureBox105
            // 
            this.pictureBox105.BackColor = System.Drawing.Color.White;
            this.pictureBox105.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox105.Location = new System.Drawing.Point(1, 70);
            this.pictureBox105.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox105.Name = "pictureBox105";
            this.pictureBox105.Size = new System.Drawing.Size(55, 68);
            this.pictureBox105.TabIndex = 19;
            this.pictureBox105.TabStop = false;
            // 
            // tableLayoutPanel67
            // 
            this.tableLayoutPanel67.ColumnCount = 1;
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel67.Controls.Add(this.lblNrPola27, 0, 0);
            this.tableLayoutPanel67.Controls.Add(this.tableLayoutPanel68, 0, 1);
            this.tableLayoutPanel67.Controls.Add(this.tableLayoutPanel69, 0, 3);
            this.tableLayoutPanel67.Controls.Add(this.pictureBox100, 0, 2);
            this.tableLayoutPanel67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel67.Location = new System.Drawing.Point(296, 1);
            this.tableLayoutPanel67.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel67.Name = "tableLayoutPanel67";
            this.tableLayoutPanel67.RowCount = 4;
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel67.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel67.TabIndex = 19;
            // 
            // lblNrPola27
            // 
            this.lblNrPola27.BackColor = System.Drawing.Color.Purple;
            this.lblNrPola27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola27.ForeColor = System.Drawing.Color.White;
            this.lblNrPola27.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola27.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola27.Name = "lblNrPola27";
            this.lblNrPola27.Size = new System.Drawing.Size(55, 15);
            this.lblNrPola27.TabIndex = 18;
            this.lblNrPola27.Text = "27";
            this.lblNrPola27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel68
            // 
            this.tableLayoutPanel68.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel68.ColumnCount = 1;
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel68.Controls.Add(this.label60, 0, 1);
            this.tableLayoutPanel68.Controls.Add(this.label61, 0, 0);
            this.tableLayoutPanel68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel68.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel68.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel68.Name = "tableLayoutPanel68";
            this.tableLayoutPanel68.RowCount = 2;
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel68.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel68.TabIndex = 20;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.Silver;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(1, 26);
            this.label60.Margin = new System.Windows.Forms.Padding(1);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(53, 23);
            this.label60.TabIndex = 10;
            this.label60.Text = "cena";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(1, 1);
            this.label61.Margin = new System.Windows.Forms.Padding(1);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(53, 23);
            this.label61.TabIndex = 10;
            this.label61.Text = "nazwa";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel69
            // 
            this.tableLayoutPanel69.ColumnCount = 2;
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel69.Controls.Add(this.pictureBox96, 1, 1);
            this.tableLayoutPanel69.Controls.Add(this.pictureBox97, 0, 1);
            this.tableLayoutPanel69.Controls.Add(this.pictureBox98, 1, 0);
            this.tableLayoutPanel69.Controls.Add(this.pictureBox99, 0, 0);
            this.tableLayoutPanel69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel69.Location = new System.Drawing.Point(1, 140);
            this.tableLayoutPanel69.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel69.Name = "tableLayoutPanel69";
            this.tableLayoutPanel69.RowCount = 2;
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel69.Size = new System.Drawing.Size(55, 34);
            this.tableLayoutPanel69.TabIndex = 18;
            // 
            // pictureBox96
            // 
            this.pictureBox96.BackColor = System.Drawing.Color.Purple;
            this.pictureBox96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox96.Location = new System.Drawing.Point(28, 18);
            this.pictureBox96.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox96.Name = "pictureBox96";
            this.pictureBox96.Size = new System.Drawing.Size(26, 15);
            this.pictureBox96.TabIndex = 12;
            this.pictureBox96.TabStop = false;
            // 
            // pictureBox97
            // 
            this.pictureBox97.BackColor = System.Drawing.Color.Purple;
            this.pictureBox97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox97.Location = new System.Drawing.Point(1, 18);
            this.pictureBox97.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox97.Name = "pictureBox97";
            this.pictureBox97.Size = new System.Drawing.Size(25, 15);
            this.pictureBox97.TabIndex = 11;
            this.pictureBox97.TabStop = false;
            // 
            // pictureBox98
            // 
            this.pictureBox98.BackColor = System.Drawing.Color.Purple;
            this.pictureBox98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox98.Location = new System.Drawing.Point(28, 1);
            this.pictureBox98.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox98.Name = "pictureBox98";
            this.pictureBox98.Size = new System.Drawing.Size(26, 15);
            this.pictureBox98.TabIndex = 10;
            this.pictureBox98.TabStop = false;
            // 
            // pictureBox99
            // 
            this.pictureBox99.BackColor = System.Drawing.Color.Purple;
            this.pictureBox99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox99.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox99.Location = new System.Drawing.Point(1, 1);
            this.pictureBox99.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox99.Name = "pictureBox99";
            this.pictureBox99.Size = new System.Drawing.Size(25, 15);
            this.pictureBox99.TabIndex = 9;
            this.pictureBox99.TabStop = false;
            // 
            // pictureBox100
            // 
            this.pictureBox100.BackColor = System.Drawing.Color.White;
            this.pictureBox100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox100.Location = new System.Drawing.Point(1, 70);
            this.pictureBox100.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox100.Name = "pictureBox100";
            this.pictureBox100.Size = new System.Drawing.Size(55, 68);
            this.pictureBox100.TabIndex = 19;
            this.pictureBox100.TabStop = false;
            // 
            // tableLayoutPanel64
            // 
            this.tableLayoutPanel64.ColumnCount = 1;
            this.tableLayoutPanel64.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel64.Controls.Add(this.lblNrPola25, 0, 0);
            this.tableLayoutPanel64.Controls.Add(this.tableLayoutPanel65, 0, 1);
            this.tableLayoutPanel64.Controls.Add(this.tableLayoutPanel66, 0, 3);
            this.tableLayoutPanel64.Controls.Add(this.pictureBox95, 0, 2);
            this.tableLayoutPanel64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel64.Location = new System.Drawing.Point(178, 1);
            this.tableLayoutPanel64.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel64.Name = "tableLayoutPanel64";
            this.tableLayoutPanel64.RowCount = 4;
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel64.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel64.TabIndex = 19;
            // 
            // lblNrPola25
            // 
            this.lblNrPola25.BackColor = System.Drawing.Color.Green;
            this.lblNrPola25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola25.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola25.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola25.Name = "lblNrPola25";
            this.lblNrPola25.Size = new System.Drawing.Size(55, 15);
            this.lblNrPola25.TabIndex = 18;
            this.lblNrPola25.Text = "25";
            this.lblNrPola25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel65
            // 
            this.tableLayoutPanel65.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel65.ColumnCount = 1;
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel65.Controls.Add(this.label57, 0, 1);
            this.tableLayoutPanel65.Controls.Add(this.label58, 0, 0);
            this.tableLayoutPanel65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel65.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel65.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel65.Name = "tableLayoutPanel65";
            this.tableLayoutPanel65.RowCount = 2;
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel65.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel65.TabIndex = 20;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.Silver;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(1, 26);
            this.label57.Margin = new System.Windows.Forms.Padding(1);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(53, 23);
            this.label57.TabIndex = 10;
            this.label57.Text = "cena";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(1, 1);
            this.label58.Margin = new System.Windows.Forms.Padding(1);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(53, 23);
            this.label58.TabIndex = 10;
            this.label58.Text = "nazwa";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel66
            // 
            this.tableLayoutPanel66.ColumnCount = 2;
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel66.Controls.Add(this.pictureBox91, 1, 1);
            this.tableLayoutPanel66.Controls.Add(this.pictureBox92, 0, 1);
            this.tableLayoutPanel66.Controls.Add(this.pictureBox93, 1, 0);
            this.tableLayoutPanel66.Controls.Add(this.pictureBox94, 0, 0);
            this.tableLayoutPanel66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel66.Location = new System.Drawing.Point(1, 140);
            this.tableLayoutPanel66.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel66.Name = "tableLayoutPanel66";
            this.tableLayoutPanel66.RowCount = 2;
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel66.Size = new System.Drawing.Size(55, 34);
            this.tableLayoutPanel66.TabIndex = 18;
            // 
            // pictureBox91
            // 
            this.pictureBox91.BackColor = System.Drawing.Color.Green;
            this.pictureBox91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox91.Location = new System.Drawing.Point(28, 18);
            this.pictureBox91.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox91.Name = "pictureBox91";
            this.pictureBox91.Size = new System.Drawing.Size(26, 15);
            this.pictureBox91.TabIndex = 12;
            this.pictureBox91.TabStop = false;
            // 
            // pictureBox92
            // 
            this.pictureBox92.BackColor = System.Drawing.Color.Green;
            this.pictureBox92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox92.Location = new System.Drawing.Point(1, 18);
            this.pictureBox92.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox92.Name = "pictureBox92";
            this.pictureBox92.Size = new System.Drawing.Size(25, 15);
            this.pictureBox92.TabIndex = 11;
            this.pictureBox92.TabStop = false;
            // 
            // pictureBox93
            // 
            this.pictureBox93.BackColor = System.Drawing.Color.Green;
            this.pictureBox93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox93.Location = new System.Drawing.Point(28, 1);
            this.pictureBox93.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox93.Name = "pictureBox93";
            this.pictureBox93.Size = new System.Drawing.Size(26, 15);
            this.pictureBox93.TabIndex = 10;
            this.pictureBox93.TabStop = false;
            // 
            // pictureBox94
            // 
            this.pictureBox94.BackColor = System.Drawing.Color.Green;
            this.pictureBox94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox94.Location = new System.Drawing.Point(1, 1);
            this.pictureBox94.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox94.Name = "pictureBox94";
            this.pictureBox94.Size = new System.Drawing.Size(25, 15);
            this.pictureBox94.TabIndex = 9;
            this.pictureBox94.TabStop = false;
            // 
            // pictureBox95
            // 
            this.pictureBox95.BackColor = System.Drawing.Color.White;
            this.pictureBox95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox95.Location = new System.Drawing.Point(1, 70);
            this.pictureBox95.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox95.Name = "pictureBox95";
            this.pictureBox95.Size = new System.Drawing.Size(55, 68);
            this.pictureBox95.TabIndex = 19;
            this.pictureBox95.TabStop = false;
            // 
            // tableLayoutPanel61
            // 
            this.tableLayoutPanel61.ColumnCount = 1;
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel61.Controls.Add(this.lblNrPola24, 0, 0);
            this.tableLayoutPanel61.Controls.Add(this.tableLayoutPanel62, 0, 1);
            this.tableLayoutPanel61.Controls.Add(this.tableLayoutPanel63, 0, 3);
            this.tableLayoutPanel61.Controls.Add(this.pictureBox90, 0, 2);
            this.tableLayoutPanel61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel61.Location = new System.Drawing.Point(119, 1);
            this.tableLayoutPanel61.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel61.Name = "tableLayoutPanel61";
            this.tableLayoutPanel61.RowCount = 4;
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel61.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel61.TabIndex = 19;
            // 
            // lblNrPola24
            // 
            this.lblNrPola24.BackColor = System.Drawing.Color.Green;
            this.lblNrPola24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola24.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola24.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola24.Name = "lblNrPola24";
            this.lblNrPola24.Size = new System.Drawing.Size(55, 15);
            this.lblNrPola24.TabIndex = 18;
            this.lblNrPola24.Text = "24";
            this.lblNrPola24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel62
            // 
            this.tableLayoutPanel62.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel62.ColumnCount = 1;
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel62.Controls.Add(this.label54, 0, 1);
            this.tableLayoutPanel62.Controls.Add(this.label55, 0, 0);
            this.tableLayoutPanel62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel62.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel62.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel62.Name = "tableLayoutPanel62";
            this.tableLayoutPanel62.RowCount = 2;
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel62.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel62.TabIndex = 20;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Silver;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(1, 26);
            this.label54.Margin = new System.Windows.Forms.Padding(1);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(53, 23);
            this.label54.TabIndex = 10;
            this.label54.Text = "cena";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(1, 1);
            this.label55.Margin = new System.Windows.Forms.Padding(1);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(53, 23);
            this.label55.TabIndex = 10;
            this.label55.Text = "nazwa";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel63
            // 
            this.tableLayoutPanel63.ColumnCount = 2;
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel63.Controls.Add(this.pictureBox86, 1, 1);
            this.tableLayoutPanel63.Controls.Add(this.pictureBox87, 0, 1);
            this.tableLayoutPanel63.Controls.Add(this.pictureBox88, 1, 0);
            this.tableLayoutPanel63.Controls.Add(this.pictureBox89, 0, 0);
            this.tableLayoutPanel63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel63.Location = new System.Drawing.Point(1, 140);
            this.tableLayoutPanel63.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel63.Name = "tableLayoutPanel63";
            this.tableLayoutPanel63.RowCount = 2;
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel63.Size = new System.Drawing.Size(55, 34);
            this.tableLayoutPanel63.TabIndex = 18;
            // 
            // pictureBox86
            // 
            this.pictureBox86.BackColor = System.Drawing.Color.Green;
            this.pictureBox86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox86.Location = new System.Drawing.Point(28, 18);
            this.pictureBox86.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox86.Name = "pictureBox86";
            this.pictureBox86.Size = new System.Drawing.Size(26, 15);
            this.pictureBox86.TabIndex = 12;
            this.pictureBox86.TabStop = false;
            // 
            // pictureBox87
            // 
            this.pictureBox87.BackColor = System.Drawing.Color.Green;
            this.pictureBox87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox87.Location = new System.Drawing.Point(1, 18);
            this.pictureBox87.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox87.Name = "pictureBox87";
            this.pictureBox87.Size = new System.Drawing.Size(25, 15);
            this.pictureBox87.TabIndex = 11;
            this.pictureBox87.TabStop = false;
            // 
            // pictureBox88
            // 
            this.pictureBox88.BackColor = System.Drawing.Color.Green;
            this.pictureBox88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox88.Location = new System.Drawing.Point(28, 1);
            this.pictureBox88.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox88.Name = "pictureBox88";
            this.pictureBox88.Size = new System.Drawing.Size(26, 15);
            this.pictureBox88.TabIndex = 10;
            this.pictureBox88.TabStop = false;
            // 
            // pictureBox89
            // 
            this.pictureBox89.BackColor = System.Drawing.Color.Green;
            this.pictureBox89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox89.Location = new System.Drawing.Point(1, 1);
            this.pictureBox89.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox89.Name = "pictureBox89";
            this.pictureBox89.Size = new System.Drawing.Size(25, 15);
            this.pictureBox89.TabIndex = 9;
            this.pictureBox89.TabStop = false;
            // 
            // pictureBox90
            // 
            this.pictureBox90.BackColor = System.Drawing.Color.White;
            this.pictureBox90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox90.Location = new System.Drawing.Point(1, 70);
            this.pictureBox90.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox90.Name = "pictureBox90";
            this.pictureBox90.Size = new System.Drawing.Size(55, 68);
            this.pictureBox90.TabIndex = 19;
            this.pictureBox90.TabStop = false;
            // 
            // tableLayoutPanel58
            // 
            this.tableLayoutPanel58.ColumnCount = 1;
            this.tableLayoutPanel58.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel58.Controls.Add(this.lblNrPola22, 0, 0);
            this.tableLayoutPanel58.Controls.Add(this.tableLayoutPanel59, 0, 1);
            this.tableLayoutPanel58.Controls.Add(this.tableLayoutPanel60, 0, 3);
            this.tableLayoutPanel58.Controls.Add(this.pictureBox85, 0, 2);
            this.tableLayoutPanel58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel58.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel58.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel58.Name = "tableLayoutPanel58";
            this.tableLayoutPanel58.RowCount = 4;
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel58.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel58.TabIndex = 19;
            // 
            // lblNrPola22
            // 
            this.lblNrPola22.BackColor = System.Drawing.Color.Green;
            this.lblNrPola22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola22.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola22.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola22.Name = "lblNrPola22";
            this.lblNrPola22.Size = new System.Drawing.Size(55, 15);
            this.lblNrPola22.TabIndex = 18;
            this.lblNrPola22.Text = "22";
            this.lblNrPola22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel59
            // 
            this.tableLayoutPanel59.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel59.ColumnCount = 1;
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel59.Controls.Add(this.label51, 0, 1);
            this.tableLayoutPanel59.Controls.Add(this.label52, 0, 0);
            this.tableLayoutPanel59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel59.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel59.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel59.Name = "tableLayoutPanel59";
            this.tableLayoutPanel59.RowCount = 2;
            this.tableLayoutPanel59.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel59.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel59.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel59.TabIndex = 20;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Silver;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(1, 26);
            this.label51.Margin = new System.Windows.Forms.Padding(1);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 23);
            this.label51.TabIndex = 10;
            this.label51.Text = "cena";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(1, 1);
            this.label52.Margin = new System.Windows.Forms.Padding(1);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(53, 23);
            this.label52.TabIndex = 10;
            this.label52.Text = "nazwa";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel60
            // 
            this.tableLayoutPanel60.ColumnCount = 2;
            this.tableLayoutPanel60.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel60.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel60.Controls.Add(this.pictureBox81, 1, 1);
            this.tableLayoutPanel60.Controls.Add(this.pictureBox82, 0, 1);
            this.tableLayoutPanel60.Controls.Add(this.pictureBox83, 1, 0);
            this.tableLayoutPanel60.Controls.Add(this.pictureBox84, 0, 0);
            this.tableLayoutPanel60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel60.Location = new System.Drawing.Point(1, 140);
            this.tableLayoutPanel60.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel60.Name = "tableLayoutPanel60";
            this.tableLayoutPanel60.RowCount = 2;
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel60.Size = new System.Drawing.Size(55, 34);
            this.tableLayoutPanel60.TabIndex = 18;
            // 
            // pictureBox81
            // 
            this.pictureBox81.BackColor = System.Drawing.Color.Green;
            this.pictureBox81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox81.Location = new System.Drawing.Point(28, 18);
            this.pictureBox81.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(26, 15);
            this.pictureBox81.TabIndex = 12;
            this.pictureBox81.TabStop = false;
            // 
            // pictureBox82
            // 
            this.pictureBox82.BackColor = System.Drawing.Color.Green;
            this.pictureBox82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox82.Location = new System.Drawing.Point(1, 18);
            this.pictureBox82.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(25, 15);
            this.pictureBox82.TabIndex = 11;
            this.pictureBox82.TabStop = false;
            // 
            // pictureBox83
            // 
            this.pictureBox83.BackColor = System.Drawing.Color.Green;
            this.pictureBox83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox83.Location = new System.Drawing.Point(28, 1);
            this.pictureBox83.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(26, 15);
            this.pictureBox83.TabIndex = 10;
            this.pictureBox83.TabStop = false;
            // 
            // pictureBox84
            // 
            this.pictureBox84.BackColor = System.Drawing.Color.Green;
            this.pictureBox84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox84.Location = new System.Drawing.Point(1, 1);
            this.pictureBox84.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox84.Name = "pictureBox84";
            this.pictureBox84.Size = new System.Drawing.Size(25, 15);
            this.pictureBox84.TabIndex = 9;
            this.pictureBox84.TabStop = false;
            // 
            // pictureBox85
            // 
            this.pictureBox85.BackColor = System.Drawing.Color.White;
            this.pictureBox85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox85.Location = new System.Drawing.Point(1, 70);
            this.pictureBox85.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox85.Name = "pictureBox85";
            this.pictureBox85.Size = new System.Drawing.Size(55, 68);
            this.pictureBox85.TabIndex = 19;
            this.pictureBox85.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox5, 2, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(1518, 334);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel1.TabIndex = 18;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel2.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Silver;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(1, 28);
            this.label8.Margin = new System.Windows.Forms.Padding(1);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 26);
            this.label8.TabIndex = 10;
            this.label8.Text = "cena";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(1, 1);
            this.label9.Margin = new System.Windows.Forms.Padding(1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 25);
            this.label9.TabIndex = 10;
            this.label9.Text = "nazwa";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Red;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(1, 1);
            this.label10.Margin = new System.Windows.Forms.Padding(1);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 55);
            this.label10.TabIndex = 7;
            this.label10.Text = "1";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.pictureBox1, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox2, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox3, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox4, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(212, 1);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(52, 55);
            this.tableLayoutPanel3.TabIndex = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Red;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(27, 28);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 26);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Red;
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Location = new System.Drawing.Point(1, 28);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 26);
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Red;
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Location = new System.Drawing.Point(27, 1);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(24, 25);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Red;
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox4.Location = new System.Drawing.Point(1, 1);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(24, 25);
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox5.Location = new System.Drawing.Point(106, 1);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(104, 55);
            this.pictureBox5.TabIndex = 9;
            this.pictureBox5.TabStop = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel6, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel7, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox10, 0, 2);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(1637, 136);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel4.TabIndex = 20;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Red;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(1, 1);
            this.label14.Margin = new System.Windows.Forms.Padding(1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 15);
            this.label14.TabIndex = 18;
            this.label14.Text = "1";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.label15, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel6.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Silver;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(1, 26);
            this.label15.Margin = new System.Windows.Forms.Padding(1);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 23);
            this.label15.TabIndex = 10;
            this.label15.Text = "cena";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(1, 1);
            this.label16.Margin = new System.Windows.Forms.Padding(1);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 23);
            this.label16.TabIndex = 10;
            this.label16.Text = "nazwa";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.pictureBox6, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox7, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox8, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox9, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(1, 140);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(55, 34);
            this.tableLayoutPanel7.TabIndex = 18;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Red;
            this.pictureBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox6.Location = new System.Drawing.Point(28, 18);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(26, 15);
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Red;
            this.pictureBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox7.Location = new System.Drawing.Point(1, 18);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 15);
            this.pictureBox7.TabIndex = 11;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Red;
            this.pictureBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox8.Location = new System.Drawing.Point(28, 1);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(26, 15);
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Red;
            this.pictureBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox9.Location = new System.Drawing.Point(1, 1);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 15);
            this.pictureBox9.TabIndex = 9;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.White;
            this.pictureBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox10.Location = new System.Drawing.Point(1, 70);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(55, 68);
            this.pictureBox10.TabIndex = 19;
            this.pictureBox10.TabStop = false;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 4;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.pictureBox15, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.pictureBox11, 3, 0);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(1516, 409);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel8.TabIndex = 21;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.label17, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(27, 1);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel9.TabIndex = 9;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Silver;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(1, 28);
            this.label17.Margin = new System.Windows.Forms.Padding(1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 26);
            this.label17.TabIndex = 10;
            this.label17.Text = "cena";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(1, 1);
            this.label18.Margin = new System.Windows.Forms.Padding(1);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 25);
            this.label18.TabIndex = 10;
            this.label18.Text = "nazwa";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Location = new System.Drawing.Point(1, 1);
            this.label19.Margin = new System.Windows.Forms.Padding(1);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(24, 55);
            this.label19.TabIndex = 7;
            this.label19.Text = "1";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.White;
            this.pictureBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox15.Location = new System.Drawing.Point(106, 1);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(104, 55);
            this.pictureBox15.TabIndex = 9;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox11.InitialImage = null;
            this.pictureBox11.Location = new System.Drawing.Point(212, 1);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(52, 55);
            this.pictureBox11.TabIndex = 10;
            this.pictureBox11.TabStop = false;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.pictureBox12, 0, 3);
            this.tableLayoutPanel11.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.pictureBox25, 0, 2);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(1722, 137);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 4;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel11.TabIndex = 22;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox12.InitialImage = null;
            this.pictureBox12.Location = new System.Drawing.Point(1, 122);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(55, 52);
            this.pictureBox12.TabIndex = 23;
            this.pictureBox12.TabStop = false;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.Red;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(1, 1);
            this.label35.Margin = new System.Windows.Forms.Padding(1);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(55, 15);
            this.label35.TabIndex = 18;
            this.label35.Text = "1";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.label36, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(1, 18);
            this.tableLayoutPanel12.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel12.TabIndex = 20;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Silver;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(1, 26);
            this.label36.Margin = new System.Windows.Forms.Padding(1);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(53, 23);
            this.label36.TabIndex = 10;
            this.label36.Text = "cena";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(1, 1);
            this.label37.Margin = new System.Windows.Forms.Padding(1);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 23);
            this.label37.TabIndex = 10;
            this.label37.Text = "nazwa";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.White;
            this.pictureBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox25.Location = new System.Drawing.Point(1, 70);
            this.pictureBox25.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(55, 50);
            this.pictureBox25.TabIndex = 19;
            this.pictureBox25.TabStop = false;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 4;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel16.Controls.Add(this.pictureBox23, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.pictureBox24, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 2, 0);
            this.tableLayoutPanel16.Controls.Add(this.label49, 3, 0);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(1516, 482);
            this.tableLayoutPanel16.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel16.TabIndex = 23;
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.White;
            this.pictureBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox23.Location = new System.Drawing.Point(54, 1);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(104, 55);
            this.pictureBox23.TabIndex = 9;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox24.InitialImage = null;
            this.pictureBox24.Location = new System.Drawing.Point(1, 1);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(51, 55);
            this.pictureBox24.TabIndex = 10;
            this.pictureBox24.TabStop = false;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel17.ColumnCount = 1;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Controls.Add(this.label47, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.label48, 0, 0);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(160, 1);
            this.tableLayoutPanel17.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 2;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(77, 55);
            this.tableLayoutPanel17.TabIndex = 9;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Silver;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(1, 28);
            this.label47.Margin = new System.Windows.Forms.Padding(1);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(75, 26);
            this.label47.TabIndex = 10;
            this.label47.Text = "cena";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(1, 1);
            this.label48.Margin = new System.Windows.Forms.Padding(1);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(75, 25);
            this.label48.TabIndex = 10;
            this.label48.Text = "nazwa";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(239, 1);
            this.label49.Margin = new System.Windows.Forms.Padding(1);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(25, 55);
            this.label49.TabIndex = 7;
            this.label49.Text = "1";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Controls.Add(this.pictureBox28, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.tableLayoutPanel24, 0, 2);
            this.tableLayoutPanel23.Controls.Add(this.pictureBox29, 0, 1);
            this.tableLayoutPanel23.Controls.Add(this.label98, 0, 3);
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1456, 696);
            this.tableLayoutPanel23.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 4;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel23.TabIndex = 24;
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackgroundImage = global::Projekt_zespolowy.Properties.Resources.kolej_ikonka;
            this.pictureBox28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox28.InitialImage = null;
            this.pictureBox28.Location = new System.Drawing.Point(1, 1);
            this.pictureBox28.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(55, 50);
            this.pictureBox28.TabIndex = 23;
            this.pictureBox28.TabStop = false;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Controls.Add(this.label99, 0, 1);
            this.tableLayoutPanel24.Controls.Add(this.label100, 0, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(1, 105);
            this.tableLayoutPanel24.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(55, 50);
            this.tableLayoutPanel24.TabIndex = 20;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.BackColor = System.Drawing.Color.Silver;
            this.label99.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label99.Location = new System.Drawing.Point(1, 26);
            this.label99.Margin = new System.Windows.Forms.Padding(1);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(53, 23);
            this.label99.TabIndex = 10;
            this.label99.Text = "cena";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label100.Location = new System.Drawing.Point(1, 1);
            this.label100.Margin = new System.Windows.Forms.Padding(1);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(53, 23);
            this.label100.TabIndex = 10;
            this.label100.Text = "nazwa";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.White;
            this.pictureBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox29.Location = new System.Drawing.Point(1, 53);
            this.pictureBox29.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(55, 50);
            this.pictureBox29.TabIndex = 19;
            this.pictureBox29.TabStop = false;
            // 
            // label98
            // 
            this.label98.BackColor = System.Drawing.Color.Red;
            this.label98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label98.Location = new System.Drawing.Point(1, 157);
            this.label98.Margin = new System.Windows.Forms.Padding(1);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(55, 17);
            this.label98.TabIndex = 18;
            this.label98.Text = "1";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel28.Controls.Add(this.lblNrPola18, 0, 0);
            this.tableLayoutPanel28.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(1, 119);
            this.tableLayoutPanel28.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(265, 57);
            this.tableLayoutPanel28.TabIndex = 25;
            // 
            // lblNrPola18
            // 
            this.lblNrPola18.AutoSize = true;
            this.lblNrPola18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola18.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola18.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola18.Name = "lblNrPola18";
            this.lblNrPola18.Size = new System.Drawing.Size(24, 55);
            this.lblNrPola18.TabIndex = 26;
            this.lblNrPola18.Text = "18";
            this.lblNrPola18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel29.Controls.Add(this.lblNrPola34, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.label106, 0, 0);
            this.tableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(1, 119);
            this.tableLayoutPanel29.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(266, 57);
            this.tableLayoutPanel29.TabIndex = 26;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.BackColor = System.Drawing.Color.White;
            this.label106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label106.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label106.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label106.ForeColor = System.Drawing.Color.Blue;
            this.label106.Location = new System.Drawing.Point(0, 0);
            this.label106.Margin = new System.Windows.Forms.Padding(0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(239, 57);
            this.label106.TabIndex = 19;
            this.label106.Text = "?";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel30.Controls.Add(this.lblNrPola37, 1, 0);
            this.tableLayoutPanel30.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(1, 296);
            this.tableLayoutPanel30.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(266, 57);
            this.tableLayoutPanel30.TabIndex = 27;
            // 
            // lblNrPola37
            // 
            this.lblNrPola37.AutoSize = true;
            this.lblNrPola37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola37.Location = new System.Drawing.Point(240, 1);
            this.lblNrPola37.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola37.Name = "lblNrPola37";
            this.lblNrPola37.Size = new System.Drawing.Size(25, 55);
            this.lblNrPola37.TabIndex = 26;
            this.lblNrPola37.Text = "37";
            this.lblNrPola37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola34
            // 
            this.lblNrPola34.AutoSize = true;
            this.lblNrPola34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola34.Location = new System.Drawing.Point(240, 1);
            this.lblNrPola34.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola34.Name = "lblNrPola34";
            this.lblNrPola34.Size = new System.Drawing.Size(25, 55);
            this.lblNrPola34.TabIndex = 28;
            this.lblNrPola34.Text = "34";
            this.lblNrPola34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel52
            // 
            this.tableLayoutPanel52.ColumnCount = 1;
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.Controls.Add(this.lblNrPola23, 0, 0);
            this.tableLayoutPanel52.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel52.Location = new System.Drawing.Point(60, 1);
            this.tableLayoutPanel52.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel52.Name = "tableLayoutPanel52";
            this.tableLayoutPanel52.RowCount = 2;
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel52.Size = new System.Drawing.Size(57, 175);
            this.tableLayoutPanel52.TabIndex = 25;
            // 
            // tableLayoutPanel53
            // 
            this.tableLayoutPanel53.ColumnCount = 1;
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel53.Controls.Add(this.lblNrPola03, 0, 1);
            this.tableLayoutPanel53.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel53.Location = new System.Drawing.Point(413, 0);
            this.tableLayoutPanel53.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel53.Name = "tableLayoutPanel53";
            this.tableLayoutPanel53.RowCount = 2;
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel53.Size = new System.Drawing.Size(59, 178);
            this.tableLayoutPanel53.TabIndex = 26;
            // 
            // tableLayoutPanel54
            // 
            this.tableLayoutPanel54.ColumnCount = 1;
            this.tableLayoutPanel54.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel54.Controls.Add(this.lblNrPola08, 0, 1);
            this.tableLayoutPanel54.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel54.Location = new System.Drawing.Point(119, 1);
            this.tableLayoutPanel54.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel54.Name = "tableLayoutPanel54";
            this.tableLayoutPanel54.RowCount = 2;
            this.tableLayoutPanel54.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel54.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel54.Size = new System.Drawing.Size(57, 176);
            this.tableLayoutPanel54.TabIndex = 27;
            // 
            // lblNrPola08
            // 
            this.lblNrPola08.AutoSize = true;
            this.lblNrPola08.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola08.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola08.Location = new System.Drawing.Point(1, 159);
            this.lblNrPola08.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola08.Name = "lblNrPola08";
            this.lblNrPola08.Size = new System.Drawing.Size(55, 16);
            this.lblNrPola08.TabIndex = 28;
            this.lblNrPola08.Text = "8";
            this.lblNrPola08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola23
            // 
            this.lblNrPola23.AutoSize = true;
            this.lblNrPola23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola23.Location = new System.Drawing.Point(1, 1);
            this.lblNrPola23.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola23.Name = "lblNrPola23";
            this.lblNrPola23.Size = new System.Drawing.Size(55, 15);
            this.lblNrPola23.TabIndex = 29;
            this.lblNrPola23.Text = "23";
            this.lblNrPola23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrPola03
            // 
            this.lblNrPola03.AutoSize = true;
            this.lblNrPola03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblNrPola03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNrPola03.Location = new System.Drawing.Point(1, 161);
            this.lblNrPola03.Margin = new System.Windows.Forms.Padding(1);
            this.lblNrPola03.Name = "lblNrPola03";
            this.lblNrPola03.Size = new System.Drawing.Size(57, 16);
            this.lblNrPola03.TabIndex = 30;
            this.lblNrPola03.Text = "3";
            this.lblNrPola03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1856, 960);
            this.Controls.Add(this.tableLayoutPanel23);
            this.Controls.Add(this.tableLayoutPanel16);
            this.Controls.Add(this.tableLayoutPanel11);
            this.Controls.Add(this.tableLayoutPanel8);
            this.Controls.Add(this.tableLayoutPanel4);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tableLayoutPanel32);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnRzucKostka);
            this.Name = "Form1";
            this.Text = "Plansza";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            this.tableLayoutPanel32.ResumeLayout(false);
            this.tableLayoutPanel36.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel100.ResumeLayout(false);
            this.tableLayoutPanel101.ResumeLayout(false);
            this.tableLayoutPanel101.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).EndInit();
            this.tableLayoutPanel102.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).EndInit();
            this.tableLayoutPanel97.ResumeLayout(false);
            this.tableLayoutPanel98.ResumeLayout(false);
            this.tableLayoutPanel98.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).EndInit();
            this.tableLayoutPanel99.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).EndInit();
            this.tableLayoutPanel94.ResumeLayout(false);
            this.tableLayoutPanel95.ResumeLayout(false);
            this.tableLayoutPanel95.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).EndInit();
            this.tableLayoutPanel96.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).EndInit();
            this.tableLayoutPanel91.ResumeLayout(false);
            this.tableLayoutPanel92.ResumeLayout(false);
            this.tableLayoutPanel92.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).EndInit();
            this.tableLayoutPanel93.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).EndInit();
            this.tableLayoutPanel88.ResumeLayout(false);
            this.tableLayoutPanel89.ResumeLayout(false);
            this.tableLayoutPanel89.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).EndInit();
            this.tableLayoutPanel90.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).EndInit();
            this.tableLayoutPanel35.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            this.tableLayoutPanel49.ResumeLayout(false);
            this.tableLayoutPanel50.ResumeLayout(false);
            this.tableLayoutPanel50.PerformLayout();
            this.tableLayoutPanel51.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            this.tableLayoutPanel46.ResumeLayout(false);
            this.tableLayoutPanel47.ResumeLayout(false);
            this.tableLayoutPanel47.PerformLayout();
            this.tableLayoutPanel48.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            this.tableLayoutPanel43.ResumeLayout(false);
            this.tableLayoutPanel44.ResumeLayout(false);
            this.tableLayoutPanel44.PerformLayout();
            this.tableLayoutPanel45.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            this.tableLayoutPanel40.ResumeLayout(false);
            this.tableLayoutPanel41.ResumeLayout(false);
            this.tableLayoutPanel41.PerformLayout();
            this.tableLayoutPanel42.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            this.tableLayoutPanel37.ResumeLayout(false);
            this.tableLayoutPanel38.ResumeLayout(false);
            this.tableLayoutPanel38.PerformLayout();
            this.tableLayoutPanel39.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            this.tableLayoutPanel82.ResumeLayout(false);
            this.tableLayoutPanel83.ResumeLayout(false);
            this.tableLayoutPanel83.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).EndInit();
            this.tableLayoutPanel84.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).EndInit();
            this.tableLayoutPanel79.ResumeLayout(false);
            this.tableLayoutPanel80.ResumeLayout(false);
            this.tableLayoutPanel80.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).EndInit();
            this.tableLayoutPanel81.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).EndInit();
            this.tableLayoutPanel76.ResumeLayout(false);
            this.tableLayoutPanel77.ResumeLayout(false);
            this.tableLayoutPanel77.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).EndInit();
            this.tableLayoutPanel78.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).EndInit();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel31.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            this.tableLayoutPanel27.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            this.tableLayoutPanel85.ResumeLayout(false);
            this.tableLayoutPanel86.ResumeLayout(false);
            this.tableLayoutPanel86.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).EndInit();
            this.tableLayoutPanel87.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).EndInit();
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.tableLayoutPanel73.ResumeLayout(false);
            this.tableLayoutPanel74.ResumeLayout(false);
            this.tableLayoutPanel74.PerformLayout();
            this.tableLayoutPanel75.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).EndInit();
            this.tableLayoutPanel70.ResumeLayout(false);
            this.tableLayoutPanel71.ResumeLayout(false);
            this.tableLayoutPanel71.PerformLayout();
            this.tableLayoutPanel72.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).EndInit();
            this.tableLayoutPanel67.ResumeLayout(false);
            this.tableLayoutPanel68.ResumeLayout(false);
            this.tableLayoutPanel68.PerformLayout();
            this.tableLayoutPanel69.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).EndInit();
            this.tableLayoutPanel64.ResumeLayout(false);
            this.tableLayoutPanel65.ResumeLayout(false);
            this.tableLayoutPanel65.PerformLayout();
            this.tableLayoutPanel66.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).EndInit();
            this.tableLayoutPanel61.ResumeLayout(false);
            this.tableLayoutPanel62.ResumeLayout(false);
            this.tableLayoutPanel62.PerformLayout();
            this.tableLayoutPanel63.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).EndInit();
            this.tableLayoutPanel58.ResumeLayout(false);
            this.tableLayoutPanel59.ResumeLayout(false);
            this.tableLayoutPanel59.PerformLayout();
            this.tableLayoutPanel60.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            this.tableLayoutPanel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel30.PerformLayout();
            this.tableLayoutPanel52.ResumeLayout(false);
            this.tableLayoutPanel52.PerformLayout();
            this.tableLayoutPanel53.ResumeLayout(false);
            this.tableLayoutPanel53.PerformLayout();
            this.tableLayoutPanel54.ResumeLayout(false);
            this.tableLayoutPanel54.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRzucKostka;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblNrPola20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel49;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel50;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lblNrPola12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel51;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel46;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel47;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblNrPola14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel48;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel43;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel44;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblNrPola15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel45;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel41;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblNrPola17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel42;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblNrPola19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel39;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel100;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel101;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.PictureBox pictureBox151;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel102;
        private System.Windows.Forms.PictureBox pictureBox152;
        private System.Windows.Forms.PictureBox pictureBox153;
        private System.Windows.Forms.PictureBox pictureBox154;
        private System.Windows.Forms.PictureBox pictureBox155;
        private System.Windows.Forms.Label lblNrPola38;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel97;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel98;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.PictureBox pictureBox146;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel99;
        private System.Windows.Forms.PictureBox pictureBox147;
        private System.Windows.Forms.PictureBox pictureBox148;
        private System.Windows.Forms.PictureBox pictureBox149;
        private System.Windows.Forms.PictureBox pictureBox150;
        private System.Windows.Forms.Label lblNrPola40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel94;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel95;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.PictureBox pictureBox141;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel96;
        private System.Windows.Forms.PictureBox pictureBox142;
        private System.Windows.Forms.PictureBox pictureBox143;
        private System.Windows.Forms.PictureBox pictureBox144;
        private System.Windows.Forms.PictureBox pictureBox145;
        private System.Windows.Forms.Label lblNrPola35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel91;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel92;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.PictureBox pictureBox136;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel93;
        private System.Windows.Forms.PictureBox pictureBox137;
        private System.Windows.Forms.PictureBox pictureBox138;
        private System.Windows.Forms.PictureBox pictureBox139;
        private System.Windows.Forms.PictureBox pictureBox140;
        private System.Windows.Forms.Label lblNrPola33;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel88;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel89;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.PictureBox pictureBox131;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel90;
        private System.Windows.Forms.PictureBox pictureBox132;
        private System.Windows.Forms.PictureBox pictureBox133;
        private System.Windows.Forms.PictureBox pictureBox134;
        private System.Windows.Forms.PictureBox pictureBox135;
        private System.Windows.Forms.Label lblNrPola32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel82;
        private System.Windows.Forms.Label lblNrPola09;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel83;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.PictureBox pictureBox121;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel84;
        private System.Windows.Forms.PictureBox pictureBox122;
        private System.Windows.Forms.PictureBox pictureBox123;
        private System.Windows.Forms.PictureBox pictureBox124;
        private System.Windows.Forms.PictureBox pictureBox125;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel79;
        private System.Windows.Forms.Label lblNrPola10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel80;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.PictureBox pictureBox116;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel81;
        private System.Windows.Forms.PictureBox pictureBox117;
        private System.Windows.Forms.PictureBox pictureBox118;
        private System.Windows.Forms.PictureBox pictureBox119;
        private System.Windows.Forms.PictureBox pictureBox120;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel76;
        private System.Windows.Forms.Label lblNrPola04;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel77;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.PictureBox pictureBox111;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel78;
        private System.Windows.Forms.PictureBox pictureBox112;
        private System.Windows.Forms.PictureBox pictureBox113;
        private System.Windows.Forms.PictureBox pictureBox114;
        private System.Windows.Forms.PictureBox pictureBox115;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lblNrPola02;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel85;
        private System.Windows.Forms.Label lblNrPola07;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel86;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.PictureBox pictureBox126;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel87;
        private System.Windows.Forms.PictureBox pictureBox127;
        private System.Windows.Forms.PictureBox pictureBox128;
        private System.Windows.Forms.PictureBox pictureBox129;
        private System.Windows.Forms.PictureBox pictureBox130;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel73;
        private System.Windows.Forms.Label lblNrPola30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel74;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel75;
        private System.Windows.Forms.PictureBox pictureBox106;
        private System.Windows.Forms.PictureBox pictureBox107;
        private System.Windows.Forms.PictureBox pictureBox108;
        private System.Windows.Forms.PictureBox pictureBox109;
        private System.Windows.Forms.PictureBox pictureBox110;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel70;
        private System.Windows.Forms.Label lblNrPola28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel71;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel72;
        private System.Windows.Forms.PictureBox pictureBox101;
        private System.Windows.Forms.PictureBox pictureBox102;
        private System.Windows.Forms.PictureBox pictureBox103;
        private System.Windows.Forms.PictureBox pictureBox104;
        private System.Windows.Forms.PictureBox pictureBox105;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel67;
        private System.Windows.Forms.Label lblNrPola27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel68;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel69;
        private System.Windows.Forms.PictureBox pictureBox96;
        private System.Windows.Forms.PictureBox pictureBox97;
        private System.Windows.Forms.PictureBox pictureBox98;
        private System.Windows.Forms.PictureBox pictureBox99;
        private System.Windows.Forms.PictureBox pictureBox100;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel64;
        private System.Windows.Forms.Label lblNrPola25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel65;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel66;
        private System.Windows.Forms.PictureBox pictureBox91;
        private System.Windows.Forms.PictureBox pictureBox92;
        private System.Windows.Forms.PictureBox pictureBox93;
        private System.Windows.Forms.PictureBox pictureBox94;
        private System.Windows.Forms.PictureBox pictureBox95;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel61;
        private System.Windows.Forms.Label lblNrPola24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel62;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel63;
        private System.Windows.Forms.PictureBox pictureBox86;
        private System.Windows.Forms.PictureBox pictureBox87;
        private System.Windows.Forms.PictureBox pictureBox88;
        private System.Windows.Forms.PictureBox pictureBox89;
        private System.Windows.Forms.PictureBox pictureBox90;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel58;
        private System.Windows.Forms.Label lblNrPola22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel59;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel60;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox82;
        private System.Windows.Forms.PictureBox pictureBox83;
        private System.Windows.Forms.PictureBox pictureBox84;
        private System.Windows.Forms.PictureBox pictureBox85;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label lblNrPola36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lblNrPola16;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.Label lblNrPola06;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label lblNrPola26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Label lblNrPola37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Label lblNrPola34;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label lblNrPola18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel52;
        private System.Windows.Forms.Label lblNrPola23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel53;
        private System.Windows.Forms.Label lblNrPola03;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel54;
        private System.Windows.Forms.Label lblNrPola08;
    }
}

