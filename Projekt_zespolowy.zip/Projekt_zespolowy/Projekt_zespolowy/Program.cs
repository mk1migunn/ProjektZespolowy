﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt_zespolowy
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            SqlConnection polaczenie = new SqlConnection();

            try
            {
                // dane do połaczenia z baza danych
                polaczenie = new SqlConnection("Server=projektasd.database.windows.net;DATABASE=monopol;User ID=master;Password=Krowa123!;");
                polaczenie.Open();

                // ta funkcja jeszcze nie działa 
                // pobierz_plansze(plansza, polaczenie);

                //wypisz(ref polaczenie);

                //funkcja sprawdzajaca ture 
                //oczekanko(polaczenie);


                // polaczenie.Close();

                //Console.ReadKey();
            }
            catch (SqlException e)
            {
                Console.WriteLine("Wystąpił nieoczekiwany błąd!");
                Console.WriteLine(e.Message);
                // Console.ReadKey();
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(polaczenie));

            //sqlClass s = new sqlClass(SqlConnection polaczenie);
            //s.main();

            polaczenie.Close();
        }
    }
}
