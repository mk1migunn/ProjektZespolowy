using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_zespolowy
{
    class Pola {
        public
        string nazwa;       // nazwa pola
        int ilosc_domkow;   // ile domkow stoi na polu (0-5, 5 to hotel)
        int koszt_uslugi;   // 
        int koszt_zakupu;   // koszt pierwszego zakupienia nieruchomosci
        int koszt_domkow;   // cena jednego domku
        float mnoznik;      
        int wlasciciel;     // numer gracza do ktorego nalezy pole (0 to niczyj)

        public Pola() {
            ilosc_domkow = 0;
        }

        public void edit( string nnazwa, int nilosc_domkow, int nkoszt_uslugi, int nkoszt_zakupu, int nkoszt_domkow, float nmnoznik, int nwlasciciel)
        {
            nazwa = nnazwa;
            ilosc_domkow = nilosc_domkow;
            koszt_uslugi = nkoszt_uslugi;
            koszt_domkow = nkoszt_domkow;
            koszt_zakupu = nkoszt_zakupu;
            mnoznik = nmnoznik;
            wlasciciel = nwlasciciel;
        }
        public void wypisz() {
            Console.WriteLine(nazwa + " " + ilosc_domkow + " " + koszt_uslugi + " " + " " + koszt_zakupu + " " + koszt_domkow + " " + mnoznik + " " + wlasciciel);
        }
    }

     
}
