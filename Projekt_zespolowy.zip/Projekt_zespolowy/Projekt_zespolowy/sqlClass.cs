using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Threading;

namespace Projekt_zespolowy
{
    class sqlClass
    {
        SqlConnection polaczenie = new SqlConnection();

        public sqlClass(SqlConnection pol)
        {
            polaczenie = pol;
        }

        //public sqlClass(SqlConnection polaczenie)
        //{
        //    this.polaczenie = polaczenie;
        //}

        static void wypisz(ref SqlConnection pol)
        {
            SqlCommand komendaSQL = pol.CreateCommand();
            komendaSQL.CommandText = "SELECT * FROM Gra_01";        // tekst zapytania
            SqlDataReader czytnik = komendaSQL.ExecuteReader();
            Console.WriteLine("Wiersze tabeli:");

            while (czytnik.Read())
            {
                Console.WriteLine(czytnik["id_gracza"] + " " + czytnik["nazwa"] + " " + czytnik["hajs"]);
            }
            czytnik.Close();
            // komendaSQL.Cancel();
        }

        static void pobierz_plansze(List<Pola> plansza, SqlConnection pol)
        {
            SqlCommand komendaSQL = pol.CreateCommand();
            komendaSQL.CommandText = "SELECT * FROM Pola";
            SqlDataReader czytnik = komendaSQL.ExecuteReader();
            Pola temp = new Pola();
            while (czytnik.Read())
            {
                //Console.WriteLine(czytnik.GetDataTypeName(0));
                //  temp.edit(czytnik["nazwa"].ToString(),czytnik["ilosc_domkow"],czytnik["koszt_uslugi"],czytnik["koszt_zakupu"],czytnik["koszt_domkow"],czytnik["mnoznik"],czytnik["wlasciciel"]);
                //  temp.edit(czytnik["nazwa"].ToString(),czytnik.GetInt16(0), czytnik.GetInt16(0), czytnik.GetInt16(0), czytnik.GetInt16(0), czytnik.GetInt16(0), czytnik.GetInt16(0));
                temp.wypisz();
            }
        }

        static int oczekanko(SqlConnection pol)
        {
            int a = 123;
            SqlCommand komenda = pol.CreateCommand();
            komenda.CommandText = "select tura_gracza from Gra_01 where id_gracza=1;";
            while (a != 1)
            {
                SqlDataReader czytnik = komenda.ExecuteReader();
                czytnik.Read();
                a = czytnik.GetInt16(0);
                Console.WriteLine(a);
                czytnik.Close();
                Thread.Sleep(5000);
            }

            if (a == 1)
                Console.WriteLine(a);
            else
                Console.WriteLine("no patrz nie udalo sie");
            return 0;
        }

        public void wrzucRzutDoBazy(int rzut)
        {
            // # kod do wrzucania rzutu
          
            SqlCommand komenda = polaczenie.CreateCommand();

            // # DOKONCZYC UPDATE TABELI "RZUT"
            // komenda.CommandText = "select tura_gracza from Gra_01 where id_gracza=1;";

            // # kod do zmiany położenia pionka gracza na planszy

        }

        public void pobierzRzutZBazy(int rzut)
        {
            // # kod do pobierania rzutu

            SqlCommand komenda = polaczenie.CreateCommand();

            // # DOKONCZYC UPDATE TABELI "RZUT"
            // komenda.CommandText = "select tura_gracza from Gra_01 where id_gracza=1;";
        }

        public void rozpoznajPole()
        {
            // # 
            // pobierz Z BAZY typ pola (trzeba zrobić)
            string temp = "";
            switch (temp)
            {
                case "dzialka":
                    break;
                case "kolej":
                    break;
                case "ryzyko":
                    break;
                case "idziesz_do_wiezienia":
                    break;
                case "dla_odwiedzajacych":
                    break;
                case "start":
                    break;
                case "elektrownia":
                    break;
                case "wodociagi":
                    break;
                case "podatek":
                    break;
                case "platny_parking":
                    break;
                case "bezplatny_parking":
                    break;
                default:
                    break;
            }
        }

        public void ruchDzialka()
        {
            bool t = false;
            // pobierz Z BAZY do kogo nalezy pole
            if (/*jest niczyje*/ t)
            {
                // wyswietl okienko decyzji zakupu pola
                if(/* kupi */ t)
                {
                    // aktualizuj BAZE 
                }
            }
            else
            {
                // pobierz Z BAZY kto jest wlascicielem
                // pobierz Z BAZY koszt naruszenia nieruchomosci
                // aktualizuj BAZE: transferuj pieniadze
            }
        }

        public void ruchKolej()
        {
            bool t = false;
            // pobierz Z BAZY do kogo nalezy pole
            if (/*jest niczyje*/ t)
            {
                // wyswietl okienko decyzji zakupu pola
                if (/* kupi */ t)
                {
                    // aktualizuj BAZE 
                }
            }
            else
            {
                // pobierz Z BAZY kto jest wlascicielem
                // pobierz Z BAZY koszt naruszenia nieruchomosci
                // aktualizuj BAZE: transferuj pieniadze
            }
        }

        public void ruchRyzyko()
        {
            string t = "";
            // pobierz Z BAZY tresc ryzyka (trzeba zrobic baze ryzyka)
            switch (t /* typ ryzka */)
            {
                case "b":
                    break;
                case "a":
                    break;
            }
            // (tu będzie dużo różnych zmian w bazie)
        }

        public void ruchIdzieszDoWiezienia()
        {

        }

        public void ruchDlaOdwiedzajacych()
        {

        }

        public void ruchStart()
        {

        }

        public void ruchElektrownia()
        {

        }

        public void ruchWodociagi()
        {

        }

        public void ruchPodatek()
        {

        }

        public void ruchParkingPlatny()
        {

        }

        public void ruchParkingBezplatny()
        {

        }







        public void main()
        {
            List<Pola> plansza = new List<Pola>();

            try
            {
                // dane do połaczenia z baza danych
                //SqlConnection polaczenie = new SqlConnection("Server=projektasd.database.windows.net;DATABASE=monopol;User ID=master;Password=Krowa123!;");
                //polaczenie.Open();

                // ta funkcja jeszcze nie działa 
               // pobierz_plansze(plansza, polaczenie);

                //wypisz(ref polaczenie);

                //funkcja sprawdzajaca ture 
                //oczekanko(polaczenie);


                //polaczenie.Close();

                //Console.ReadKey();
            }
            catch (SqlException e)
            {
                Console.WriteLine("Wystąpił nieoczekiwany błąd!");
                Console.WriteLine(e.Message);
               // Console.ReadKey();
            }



        }



    }
}
