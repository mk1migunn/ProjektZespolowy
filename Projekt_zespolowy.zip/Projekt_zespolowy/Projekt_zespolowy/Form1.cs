﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Projekt_zespolowy
{
    public partial class Form1 : Form
    {
        SqlConnection polaczenie = new SqlConnection();
         
        public Form1(SqlConnection pol)
        {
            polaczenie = pol;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();  //seed randoma
            int dice01 = 0;         // pierwsza kosc
            int dice02 = 0;         // druga kosc
            int roll = 0;           // wartosc rzutu 

            dice01 = rnd.Next(1, 7); //losuje liczbe int od 1 do 6
            dice02 = rnd.Next(1, 7); //losuje liczbe int od 1 do 6

            roll = dice01 + dice02;

            // MessageBox.Show("dice 1: " + dice01 + "\ndice 2: " + dice02 + "\n roll  : " + roll);

            for (int i = 0; i < 30; i++)
            {
                dice01 = rnd.Next(1, 7);
                dice02 = rnd.Next(1, 7);
                roll = dice01 + dice02;
                Console.WriteLine(dice01 + "\t" + dice02 + "\t" + roll);
            }

            // # wrzucić wynik do bazy danych 
            //Projekt_zespolowy.sqlClass c = new Projekt_zespolowy.sqlClass(polaczenie);
            //c.wrzucRzutDoBazy(roll);

            // # kod do wrzucania rzutu

            SqlCommand komenda = polaczenie.CreateCommand();
            sqlClass c = new sqlClass(polaczenie);
            // # DOKONCZYC UPDATE TABELI "RZUT"
            // komenda.CommandText = "select tura_gracza from Gra_01 where id_gracza=1;";       

            int foo = 1;
            int foo2 = 2;
            przesunPionek(foo, foo2);

   


        }

        public void przesunPionek(int nrGracza, int nrPola)
        {
            // usun grafikę pionka z aktualnego pola
            // pobierz współrzędne pola docelowego pionka
            // oblicz współrzędne na którym ma wylądować pionek
            // wklej grafikę pionka
        }



        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel5_Paint(object sender, PaintEventArgs e)
        {

        }

    }
}
